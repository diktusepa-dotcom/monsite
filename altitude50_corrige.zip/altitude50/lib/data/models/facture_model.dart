class FactureModel {
  const FactureModel({
    required this.id,
    required this.clientId,
    required this.numero,
    required this.date,
    required this.interventionId,
    required this.devisId,
    required this.lignes,
    required this.deplacement,
    required this.total,
    required this.remise,
    required this.statutPaiement,
    required this.modePaiement,
  });

  final int? id;
  final int clientId;
  final String numero;
  final String date;
  final int interventionId;
  final int devisId;
  final String lignes;
  final int deplacement;
  final int total;
  final int remise;
  final String statutPaiement;
  final String modePaiement;

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'clientId': clientId,
      'numero': numero,
      'date': date,
      'interventionId': interventionId,
      'devisId': devisId,
      'lignes': lignes,
      'deplacement': deplacement,
      'total': total,
      'remise': remise,
      'statutPaiement': statutPaiement,
      'modePaiement': modePaiement,
    };
  }

  factory FactureModel.fromMap(Map<String, Object?> map) {
    return FactureModel(
      id: map['id'] as int?,
      clientId: map['clientId'] as int? ?? 0,
      numero: map['numero'] as String? ?? '',
      date: map['date'] as String? ?? '',
      interventionId: map['interventionId'] as int? ?? 0,
      devisId: map['devisId'] as int? ?? 0,
      lignes: map['lignes'] as String? ?? '',
      deplacement: map['deplacement'] as int? ?? 0,
      total: map['total'] as int? ?? 0,
      remise: map['remise'] as int? ?? 0,
      statutPaiement: map['statutPaiement'] as String? ?? 'Impayée',
      modePaiement: map['modePaiement'] as String? ?? '',
    );
  }

  FactureModel copyWith({
    int? id,
    int? clientId,
    String? numero,
    String? date,
    int? interventionId,
    int? devisId,
    String? lignes,
    int? deplacement,
    int? total,
    int? remise,
    String? statutPaiement,
    String? modePaiement,
  }) {
    return FactureModel(
      id: id ?? this.id,
      clientId: clientId ?? this.clientId,
      numero: numero ?? this.numero,
      date: date ?? this.date,
      interventionId: interventionId ?? this.interventionId,
      devisId: devisId ?? this.devisId,
      lignes: lignes ?? this.lignes,
      deplacement: deplacement ?? this.deplacement,
      total: total ?? this.total,
      remise: remise ?? this.remise,
      statutPaiement: statutPaiement ?? this.statutPaiement,
      modePaiement: modePaiement ?? this.modePaiement,
    );
  }
}
