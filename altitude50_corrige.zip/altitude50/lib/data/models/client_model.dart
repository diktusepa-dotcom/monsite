class ClientModel {
  const ClientModel({
    required this.id,
    required this.nom,
    required this.prenom,
    required this.telephone,
    required this.email,
    required this.adresse,
    required this.codePostal,
    required this.ville,
    required this.notes,
    required this.dateCreation,
  });

  final int? id;
  final String nom;
  final String prenom;
  final String telephone;
  final String email;
  final String adresse;
  final String codePostal;
  final String ville;
  final String notes;
  final String dateCreation;

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'nom': nom,
      'prenom': prenom,
      'telephone': telephone,
      'email': email,
      'adresse': adresse,
      'codePostal': codePostal,
      'ville': ville,
      'notes': notes,
      'dateCreation': dateCreation,
    };
  }

  factory ClientModel.fromMap(Map<String, Object?> map) {
    return ClientModel(
      id: map['id'] as int?,
      nom: map['nom'] as String? ?? '',
      prenom: map['prenom'] as String? ?? '',
      telephone: map['telephone'] as String? ?? '',
      email: map['email'] as String? ?? '',
      adresse: map['adresse'] as String? ?? '',
      codePostal: map['codePostal'] as String? ?? '',
      ville: map['ville'] as String? ?? '',
      notes: map['notes'] as String? ?? '',
      dateCreation: map['dateCreation'] as String? ?? '',
    );
  }

  ClientModel copyWith({
    int? id,
    String? nom,
    String? prenom,
    String? telephone,
    String? email,
    String? adresse,
    String? codePostal,
    String? ville,
    String? notes,
    String? dateCreation,
  }) {
    return ClientModel(
      id: id ?? this.id,
      nom: nom ?? this.nom,
      prenom: prenom ?? this.prenom,
      telephone: telephone ?? this.telephone,
      email: email ?? this.email,
      adresse: adresse ?? this.adresse,
      codePostal: codePostal ?? this.codePostal,
      ville: ville ?? this.ville,
      notes: notes ?? this.notes,
      dateCreation: dateCreation ?? this.dateCreation,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ClientModel &&
        id == other.id &&
        nom == other.nom &&
        prenom == other.prenom &&
        telephone == other.telephone &&
        email == other.email &&
        adresse == other.adresse &&
        codePostal == other.codePostal &&
        ville == other.ville &&
        notes == other.notes &&
        dateCreation == other.dateCreation;
  }

  @override
  int get hashCode {
    return Object.hash(
      id,
      nom,
      prenom,
      telephone,
      email,
      adresse,
      codePostal,
      ville,
      notes,
      dateCreation,
    );
  }
}
