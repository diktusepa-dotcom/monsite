class DevisModel {
  const DevisModel({
    required this.id,
    required this.clientId,
    required this.numero,
    required this.date,
    required this.dateValidite,
    required this.lignes,
    required this.deplacement,
    required this.remise,
    required this.total,
    required this.statut,
    required this.notes,
  });

  final int? id;
  final int clientId;
  final String numero;
  final String date;
  final String dateValidite;
  final String lignes;
  final int deplacement;
  final int remise;
  final int total;
  final String statut;
  final String notes;

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'clientId': clientId,
      'numero': numero,
      'date': date,
      'dateValidite': dateValidite,
      'lignes': lignes,
      'deplacement': deplacement,
      'remise': remise,
      'total': total,
      'statut': statut,
      'notes': notes,
    };
  }

  factory DevisModel.fromMap(Map<String, Object?> map) {
    return DevisModel(
      id: map['id'] as int?,
      clientId: map['clientId'] as int? ?? 0,
      numero: map['numero'] as String? ?? '',
      date: map['date'] as String? ?? '',
      dateValidite: map['dateValidite'] as String? ?? '',
      lignes: map['lignes'] as String? ?? '',
      deplacement: map['deplacement'] as int? ?? 0,
      remise: map['remise'] as int? ?? 0,
      total: map['total'] as int? ?? 0,
      statut: map['statut'] as String? ?? 'brouillon',
      notes: map['notes'] as String? ?? '',
    );
  }

  DevisModel copyWith({
    int? id,
    int? clientId,
    String? numero,
    String? date,
    String? dateValidite,
    String? lignes,
    int? deplacement,
    int? remise,
    int? total,
    String? statut,
    String? notes,
  }) {
    return DevisModel(
      id: id ?? this.id,
      clientId: clientId ?? this.clientId,
      numero: numero ?? this.numero,
      date: date ?? this.date,
      dateValidite: dateValidite ?? this.dateValidite,
      lignes: lignes ?? this.lignes,
      deplacement: deplacement ?? this.deplacement,
      remise: remise ?? this.remise,
      total: total ?? this.total,
      statut: statut ?? this.statut,
      notes: notes ?? this.notes,
    );
  }
}
