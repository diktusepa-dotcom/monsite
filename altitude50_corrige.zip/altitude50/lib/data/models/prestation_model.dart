class PrestationModel {
  const PrestationModel({
    required this.id,
    required this.categorie,
    required this.nom,
    required this.prix,
    required this.actif,
  });

  final int? id;
  final String categorie;
  final String nom;
  final int prix;
  final int actif;

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'categorie': categorie,
      'nom': nom,
      'prix': prix,
      'actif': actif,
    };
  }

  factory PrestationModel.fromMap(Map<String, Object?> map) {
    return PrestationModel(
      id: map['id'] as int?,
      categorie: map['categorie'] as String? ?? '',
      nom: map['nom'] as String? ?? '',
      prix: map['prix'] as int? ?? 0,
      actif: map['actif'] as int? ?? 1,
    );
  }

  PrestationModel copyWith({
    int? id,
    String? categorie,
    String? nom,
    int? prix,
    int? actif,
  }) {
    return PrestationModel(
      id: id ?? this.id,
      categorie: categorie ?? this.categorie,
      nom: nom ?? this.nom,
      prix: prix ?? this.prix,
      actif: actif ?? this.actif,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is PrestationModel &&
        id == other.id &&
        categorie == other.categorie &&
        nom == other.nom &&
        prix == other.prix &&
        actif == other.actif;
  }

  @override
  int get hashCode => Object.hash(id, categorie, nom, prix, actif);
}
