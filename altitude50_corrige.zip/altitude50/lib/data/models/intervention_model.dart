class InterventionModel {
  const InterventionModel({
    required this.id,
    required this.clientId,
    required this.date,
    required this.heure,
    required this.appareil,
    required this.marque,
    required this.modele,
    required this.problemeSignale,
    required this.diagnostic,
    required this.travailEffectue,
    required this.prestationId,
    required this.prixPrestation,
    required this.fraisDeplacement,
    required this.total,
    required this.statut,
    required this.modePaiement,
    required this.notes,
    required this.dateCreation,
  });

  final int? id;
  final int clientId;
  final String date;
  final String heure;
  final String appareil;
  final String marque;
  final String modele;
  final String problemeSignale;
  final String diagnostic;
  final String travailEffectue;
  final int prestationId;
  final int prixPrestation;
  final int fraisDeplacement;
  final int total;
  final String statut;
  final String modePaiement;
  final String notes;
  final String dateCreation;

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'clientId': clientId,
      'date': date,
      'heure': heure,
      'appareil': appareil,
      'marque': marque,
      'modele': modele,
      'problemeSignale': problemeSignale,
      'diagnostic': diagnostic,
      'travailEffectue': travailEffectue,
      'prestationId': prestationId,
      'prixPrestation': prixPrestation,
      'fraisDeplacement': fraisDeplacement,
      'total': total,
      'statut': statut,
      'modePaiement': modePaiement,
      'notes': notes,
      'dateCreation': dateCreation,
    };
  }

  factory InterventionModel.fromMap(Map<String, Object?> map) {
    return InterventionModel(
      id: map['id'] as int?,
      clientId: map['clientId'] as int? ?? 0,
      date: map['date'] as String? ?? '',
      heure: map['heure'] as String? ?? '',
      appareil: map['appareil'] as String? ?? '',
      marque: map['marque'] as String? ?? '',
      modele: map['modele'] as String? ?? '',
      problemeSignale: map['problemeSignale'] as String? ?? '',
      diagnostic: map['diagnostic'] as String? ?? '',
      travailEffectue: map['travailEffectue'] as String? ?? '',
      prestationId: map['prestationId'] as int? ?? 0,
      prixPrestation: map['prixPrestation'] as int? ?? 0,
      fraisDeplacement: map['fraisDeplacement'] as int? ?? 0,
      total: map['total'] as int? ?? 0,
      statut: map['statut'] as String? ?? '',
      modePaiement: map['modePaiement'] as String? ?? '',
      notes: map['notes'] as String? ?? '',
      dateCreation: map['dateCreation'] as String? ?? '',
    );
  }

  InterventionModel copyWith({
    int? id,
    int? clientId,
    String? date,
    String? heure,
    String? appareil,
    String? marque,
    String? modele,
    String? problemeSignale,
    String? diagnostic,
    String? travailEffectue,
    int? prestationId,
    int? prixPrestation,
    int? fraisDeplacement,
    int? total,
    String? statut,
    String? modePaiement,
    String? notes,
    String? dateCreation,
  }) {
    return InterventionModel(
      id: id ?? this.id,
      clientId: clientId ?? this.clientId,
      date: date ?? this.date,
      heure: heure ?? this.heure,
      appareil: appareil ?? this.appareil,
      marque: marque ?? this.marque,
      modele: modele ?? this.modele,
      problemeSignale: problemeSignale ?? this.problemeSignale,
      diagnostic: diagnostic ?? this.diagnostic,
      travailEffectue: travailEffectue ?? this.travailEffectue,
      prestationId: prestationId ?? this.prestationId,
      prixPrestation: prixPrestation ?? this.prixPrestation,
      fraisDeplacement: fraisDeplacement ?? this.fraisDeplacement,
      total: total ?? this.total,
      statut: statut ?? this.statut,
      modePaiement: modePaiement ?? this.modePaiement,
      notes: notes ?? this.notes,
      dateCreation: dateCreation ?? this.dateCreation,
    );
  }
}
