import 'dart:convert';
import 'dart:typed_data';

import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/devis_model.dart';
import 'package:altitude50/data/models/facture_model.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class DocumentPdfService {
  static Future<void> shareDevis(DevisModel devis, ClientModel client) async {
    final bytes = await _build('DEVIS', devis.numero, devis.date, devis.lignes, devis.deplacement, devis.remise, devis.total, client);
    await Printing.sharePdf(bytes: bytes, filename: '${devis.numero}.pdf');
  }

  static Future<void> shareFacture(FactureModel facture, ClientModel client) async {
    final bytes = await _build('FACTURE', facture.numero, facture.date, facture.lignes, facture.deplacement, facture.remise, facture.total, client);
    await Printing.sharePdf(bytes: bytes, filename: '${facture.numero}.pdf');
  }

  static Future<Uint8List> _build(String type, String number, String date, String linesJson, int travel, int discount, int total, ClientModel client) async {
    final company = await AppDatabase.instance.entrepriseSettings();
    final document = pw.Document();
    final lines = linesJson.isEmpty ? const <dynamic>[] : jsonDecode(linesJson) as List<dynamic>;
    document.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      build: (context) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(company['nom'] as String? ?? "ALT'ITUDE 50", style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
          pw.Text(company['adresse'] as String? ?? ''),
          pw.Text('${company['telephone'] as String? ?? ''} ${company['email'] as String? ?? ''}'),
          pw.Text('SIRET : ${company['siret'] as String? ?? ''}'),
          pw.SizedBox(height: 24),
          pw.Text(type, style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
          pw.Text('Numéro : $number'),
          pw.Text('Date : $date'),
          pw.SizedBox(height: 16),
          pw.Text('Client : ${client.prenom} ${client.nom}'),
          pw.Text('${client.adresse}, ${client.codePostal} ${client.ville}'),
          pw.Text(client.telephone),
          pw.Text(client.email),
          pw.SizedBox(height: 20),
          pw.TableHelper.fromTextArray(
            headers: const ['Prestation', 'Qté', 'Prix unitaire', 'Total'],
            data: lines.map((line) => [line['description'], '${line['quantite']}', '${line['prixUnitaire']} €', '${line['total']} €']).toList(),
          ),
          pw.SizedBox(height: 16),
          pw.Align(alignment: pw.Alignment.centerRight, child: pw.Text('Déplacement : $travel €')),
          pw.Align(alignment: pw.Alignment.centerRight, child: pw.Text('Remise : $discount €')),
          pw.Align(alignment: pw.Alignment.centerRight, child: pw.Text('Total : $total €', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold))),
          if (type == 'FACTURE') ...[
            pw.SizedBox(height: 24),
            pw.Text(company['tva'] as String? ?? 'TVA non applicable, art. 293 B du CGI'),
            pw.Text('Facture payable selon les conditions convenues avec le client.'),
          ],
        ],
      ),
    ));
    return document.save();
  }
}
