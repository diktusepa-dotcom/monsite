import 'dart:convert';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/client_model.dart';
import '../models/devis_model.dart';
import '../models/facture_model.dart';
import '../models/intervention_model.dart';
import '../models/prestation_model.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'altitude50.db');

    return openDatabase(
      path,
      version: 8,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onOpen: _onOpen,
    );
  }

  /// Complète les contrats de maintenance s'ils sont absents (ajout only —
  /// ne touche jamais à un tarif existant).
  Future<void> _onOpen(Database db) async {
    final maintenance = await db.query('prestations', where: "categorie = 'ABONNEMENT / MAINTENANCE'");
    if (maintenance.isEmpty) {
      await db.insert('prestations', {'categorie': 'ABONNEMENT / MAINTENANCE', 'nom': 'Contrat maintenance particulier (par an)', 'prix': 149});
      await db.insert('prestations', {'categorie': 'ABONNEMENT / MAINTENANCE', 'nom': 'Contrat maintenance petite structure (par an)', 'prix': 269});
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL,
        prenom TEXT NOT NULL,
        telephone TEXT,
        email TEXT,
        adresse TEXT,
        codePostal TEXT,
        ville TEXT,
        notes TEXT,
        dateCreation TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE interventions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        clientId INTEGER NOT NULL,
        date TEXT NOT NULL,
        heure TEXT NOT NULL,
        appareil TEXT,
        marque TEXT,
        modele TEXT,
        problemeSignale TEXT,
        diagnostic TEXT,
        travailEffectue TEXT,
        prestationId INTEGER,
        prixPrestation INTEGER,
        fraisDeplacement INTEGER,
        total INTEGER,
        statut TEXT,
        modePaiement TEXT,
        notes TEXT,
        dateCreation TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE prestations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        categorie TEXT NOT NULL,
        nom TEXT NOT NULL,
        prix INTEGER NOT NULL,
        actif INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE devis (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        clientId INTEGER NOT NULL,
        numero TEXT NOT NULL,
        date TEXT NOT NULL,
        dateValidite TEXT NOT NULL DEFAULT '',
        lignes TEXT,
        deplacement INTEGER,
        remise INTEGER NOT NULL DEFAULT 0,
        total INTEGER,
        statut TEXT,
        notes TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE factures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        clientId INTEGER NOT NULL,
        numero TEXT NOT NULL,
        date TEXT NOT NULL,
        interventionId INTEGER,
        devisId INTEGER,
        lignes TEXT,
        deplacement INTEGER,
        remise INTEGER NOT NULL DEFAULT 0,
        total INTEGER,
        statutPaiement TEXT,
        modePaiement TEXT
      )
    ''');

    await _createLineTables(db);
    await db.execute('''CREATE TABLE IF NOT EXISTS entreprise_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1), nom TEXT NOT NULL DEFAULT '', adresse TEXT NOT NULL DEFAULT '', telephone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', siret TEXT NOT NULL DEFAULT '', tva TEXT NOT NULL DEFAULT 'TVA non applicable, art. 293 B du CGI', informationsComplementaires TEXT NOT NULL DEFAULT ''
    )''');

    await _createDeplacementSettingsTable(db);
    await _seedTarifs(db);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute("ALTER TABLE devis ADD COLUMN dateValidite TEXT NOT NULL DEFAULT ''");
      await db.execute('ALTER TABLE devis ADD COLUMN remise INTEGER NOT NULL DEFAULT 0');
      await db.execute('ALTER TABLE factures ADD COLUMN devisId INTEGER');
      await db.execute('ALTER TABLE factures ADD COLUMN remise INTEGER NOT NULL DEFAULT 0');
      await _createLineTables(db);
      await db.execute('''CREATE TABLE IF NOT EXISTS entreprise_settings (
        id INTEGER PRIMARY KEY CHECK (id = 1), nom TEXT NOT NULL DEFAULT '', adresse TEXT NOT NULL DEFAULT '', telephone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', siret TEXT NOT NULL DEFAULT '', tva TEXT NOT NULL DEFAULT 'TVA non applicable, art. 293 B du CGI'
      )''');
    }
    if (oldVersion < 3) {
      await _replaceCatalogue(db);
    }
    if (oldVersion < 4) {
      await db.execute("ALTER TABLE entreprise_settings ADD COLUMN informationsComplementaires TEXT NOT NULL DEFAULT ''");
    }
    if (oldVersion < 5) {
      await _replaceCatalogue(db);
    }
    if (oldVersion < 6) {
      await _createDeplacementSettingsTable(db);
    }
    if (oldVersion < 7) {
      await _replaceCatalogue(db);
    }
    if (oldVersion < 8) {
      // Correction ponctuelle : remet "Accompagnement achat" à 20€ (annule
      // le passage à 30€ fait par erreur dans une version précédente). Ne
      // s'exécute qu'une fois, pas à chaque ouverture de l'app.
      await db.update('prestations', {'prix': 20}, where: 'nom = ?', whereArgs: ['Accompagnement achat']);
    }
  }

  Future<void> _createDeplacementSettingsTable(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS deplacement_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      palier1Km INTEGER NOT NULL DEFAULT 10,
      palier1Prix INTEGER NOT NULL DEFAULT 10,
      palier2Km INTEGER NOT NULL DEFAULT 20,
      palier2Prix INTEGER NOT NULL DEFAULT 20,
      palier3Km INTEGER NOT NULL DEFAULT 30,
      palier3Prix INTEGER NOT NULL DEFAULT 30,
      distanceMax INTEGER NOT NULL DEFAULT 40
    )''');
    await db.insert(
      'deplacement_settings',
      {
        'id': 1,
        'palier1Km': 10,
        'palier1Prix': 10,
        'palier2Km': 20,
        'palier2Prix': 20,
        'palier3Km': 30,
        'palier3Prix': 30,
        'distanceMax': 40,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<void> _createLineTables(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS devis_lignes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      devisId INTEGER NOT NULL,
      prestationId INTEGER,
      description TEXT NOT NULL,
      quantite INTEGER NOT NULL,
      prixUnitaire INTEGER NOT NULL,
      total INTEGER NOT NULL
    )''');
    await db.execute('''CREATE TABLE IF NOT EXISTS facture_lignes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      factureId INTEGER NOT NULL,
      prestationId INTEGER,
      description TEXT NOT NULL,
      quantite INTEGER NOT NULL,
      prixUnitaire INTEGER NOT NULL,
      total INTEGER NOT NULL
    )''');
  }

  Future<void> _seedTarifs(Database db) async {
    final tarifs = [
      ('ORDINATEUR', 'Assistance / dépannage', 69), ('ORDINATEUR', 'PC lent', 79), ('ORDINATEUR', 'Virus / malware', 89), ('ORDINATEUR', 'Installation PC neuf', 89), ('ORDINATEUR', 'Réinstallation Windows', 109), ('ORDINATEUR', 'Installation Windows sur PC sans système', 109), ('ORDINATEUR', 'Migration SSD', 129), ('ORDINATEUR', 'Nouveau PC + transfert', 159), ('ORDINATEUR', 'Nettoyage physique', 69), ('ORDINATEUR', 'Remplacement pâte thermique', 69), ('ORDINATEUR', 'RAM', 69),
      ('TÉLÉPHONE / TABLETTE', 'Assistance / configuration', 69), ('TÉLÉPHONE / TABLETTE', 'Nouveau téléphone', 79), ('TÉLÉPHONE / TABLETTE', 'Nouveau téléphone + transfert', 129), ('TÉLÉPHONE / TABLETTE', 'Nettoyage / optimisation', 69), ('TÉLÉPHONE / TABLETTE', 'Transfert de données', 69), ('TÉLÉPHONE / TABLETTE', 'WhatsApp', 69), ('TÉLÉPHONE / TABLETTE', 'Messagerie', 69),
      ('INTERNET / WI-FI', 'Dépannage Wi-Fi', 69), ('INTERNET / WI-FI', 'Installation / configuration box', 79),
      ('IMPRIMANTE / SCANNER', 'Installation / configuration imprimante', 69), ('IMPRIMANTE / SCANNER', 'Installation / configuration scanner', 69), ('IMPRIMANTE / SCANNER', 'Installation / configuration imprimante multifonction', 89),
      ('TV / MULTIMÉDIA', 'TV connectée', 69), ('TV / MULTIMÉDIA', 'Chromecast / Google TV', 69), ('TV / MULTIMÉDIA', 'Barre de son / enceinte', 69), ('TV / MULTIMÉDIA', 'Ordinateur → TV', 69),
      ('ACCESSOIRES', 'Bluetooth', 69), ('ACCESSOIRES', 'Casque / micro / enceinte', 69), ('ACCESSOIRES', 'Webcam', 69), ('ACCESSOIRES', 'Manette', 69),
      ('FORMATION', '1 heure', 69), ('FORMATION', '2 heures', 119), ('FORMATION', '3 heures', 169),
      ('DONNÉES', 'Sauvegarde', 69), ('DONNÉES', 'Diagnostic récupération', 69), ('DONNÉES', 'Récupération simple', 99), ('DONNÉES', 'Récupération complexe', 0),
      ("ACCOMPAGNEMENT À L'ACHAT", 'Accompagnement achat', 20),
      ('ABONNEMENT / MAINTENANCE', 'Contrat maintenance particulier (par an)', 149), ('ABONNEMENT / MAINTENANCE', 'Contrat maintenance petite structure (par an)', 269),
    ];

    for (final tarif in tarifs) {
      await db.insert('prestations', {
        'categorie': tarif.$1,
        'nom': tarif.$2,
        'prix': tarif.$3,
        'actif': 1,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  Future<void> _replaceCatalogue(Database db) async {
    await db.delete('prestations');
    await _seedTarifs(db);
  }

  Future<void> resetForTesting() async {
    final db = await database;
    await db.delete('factures');
    await db.delete('devis');
    await db.delete('interventions');
    await db.delete('prestations');
    await db.delete('clients');
    await db.delete('entreprise_settings');
    await db.delete('deplacement_settings');
    await _replaceCatalogue(db);
    await _createDeplacementSettingsTable(db);
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }

  Future<Map<String, Object?>> entrepriseSettings() async {
    final db = await database;
    final rows = await db.query('entreprise_settings', where: 'id = 1', limit: 1);
    return rows.isEmpty ? <String, Object?>{} : rows.first;
  }

  Future<void> updateEntrepriseSettings(Map<String, Object?> values) async {
    final db = await database;
    await db.insert('entreprise_settings', {'id': 1, ...values}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<Map<String, Object?>> deplacementSettings() async {
    final db = await database;
    final rows = await db.query('deplacement_settings', where: 'id = 1', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    return {
      'palier1Km': 10,
      'palier1Prix': 10,
      'palier2Km': 20,
      'palier2Prix': 20,
      'palier3Km': 30,
      'palier3Prix': 30,
      'distanceMax': 40,
    };
  }

  Future<void> updateDeplacementSettings(Map<String, Object?> values) async {
    final db = await database;
    await db.insert('deplacement_settings', {'id': 1, ...values}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<ClientModel> insertClient(ClientModel client) async {
    final db = await database;
    final id = await db.insert('clients', client.toMap());
    return client.copyWith(id: id);
  }

  Future<int> updateClient(ClientModel client) async {
    final db = await database;
    return db.update(
      'clients',
      client.toMap(),
      where: 'id = ?',
      whereArgs: [client.id],
    );
  }

  Future<int> deleteClient(int id) async {
    final db = await database;
    return db.delete('clients', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<ClientModel>> clients() async {
    final db = await database;
    final rows = await db.query('clients', orderBy: 'dateCreation DESC');
    return rows.map(ClientModel.fromMap).toList();
  }

  Future<ClientModel?> clientById(int id) async {
    final db = await database;
    final rows = await db.query('clients', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return ClientModel.fromMap(rows.first);
  }

  Future<List<ClientModel>> searchClients(String query) async {
    final db = await database;
    final rows = await db.query(
      'clients',
      where: 'nom LIKE ? OR prenom LIKE ? OR ville LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'nom ASC',
    );
    return rows.map(ClientModel.fromMap).toList();
  }

  Future<PrestationModel> insertPrestation(PrestationModel prestation) async {
    final db = await database;
    final id = await db.insert('prestations', prestation.toMap());
    return prestation.copyWith(id: id);
  }

  Future<int> updatePrestation(PrestationModel prestation) async {
    final db = await database;
    return db.update(
      'prestations',
      prestation.toMap(),
      where: 'id = ?',
      whereArgs: [prestation.id],
    );
  }

  Future<List<PrestationModel>> prestations() async {
    final db = await database;
    final rows = await db.query('prestations', orderBy: 'categorie ASC, nom ASC');
    return rows.map(PrestationModel.fromMap).toList();
  }

  Future<PrestationModel?> prestationById(int id) async {
    final db = await database;
    final rows = await db.query('prestations', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return PrestationModel.fromMap(rows.first);
  }

  Future<InterventionModel> insertIntervention(InterventionModel intervention) async {
    final db = await database;
    final id = await db.insert('interventions', intervention.toMap());
    return intervention.copyWith(id: id);
  }

  Future<int> updateIntervention(InterventionModel intervention) async {
    final db = await database;
    return db.update(
      'interventions',
      intervention.toMap(),
      where: 'id = ?',
      whereArgs: [intervention.id],
    );
  }

  Future<List<InterventionModel>> interventionsByClient(int clientId) async {
    final db = await database;
    final rows = await db.query(
      'interventions',
      where: 'clientId = ?',
      whereArgs: [clientId],
      orderBy: 'date DESC, heure DESC',
    );
    return rows.map(InterventionModel.fromMap).toList();
  }

  Future<List<InterventionModel>> interventions() async {
    final db = await database;
    final rows = await db.query('interventions', orderBy: 'date DESC, heure DESC');
    return rows.map(InterventionModel.fromMap).toList();
  }

  Future<InterventionModel?> interventionById(int id) async {
    final db = await database;
    final rows = await db.query('interventions', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return InterventionModel.fromMap(rows.first);
  }

  Future<DevisModel> insertDevis(DevisModel devis) async {
    final db = await database;
    final values = devis.toMap()..remove('id');
    values['numero'] = await nextDevisNumber();
    final id = await db.insert('devis', values);
    await _saveLines(db, 'devis_lignes', 'devisId', id, devis.lignes);
    return devis.copyWith(id: id, numero: values['numero'] as String);
  }

  Future<List<DevisModel>> devis() async {
    final db = await database;
    final rows = await db.query('devis', orderBy: 'date DESC, id DESC');
    return rows.map(DevisModel.fromMap).toList();
  }

  Future<int> updateDevis(DevisModel devis) async => (await database).update('devis', devis.toMap(), where: 'id = ?', whereArgs: [devis.id]);

  Future<String> nextDevisNumber() => _nextDocumentNumber('devis', 'DEV');

  Future<List<DevisModel>> devisByClient(int clientId) async {
    final db = await database;
    final rows = await db.query('devis', where: 'clientId = ?', whereArgs: [clientId], orderBy: 'date DESC');
    return rows.map(DevisModel.fromMap).toList();
  }

  Future<FactureModel> insertFacture(FactureModel facture) async {
    final db = await database;
    final values = facture.toMap()..remove('id');
    values['numero'] = await nextFactureNumber();
    final id = await db.insert('factures', values);
    await _saveLines(db, 'facture_lignes', 'factureId', id, facture.lignes);
    return facture.copyWith(id: id, numero: values['numero'] as String);
  }

  Future<List<FactureModel>> factures() async {
    final db = await database;
    final rows = await db.query('factures', orderBy: 'date DESC, id DESC');
    return rows.map(FactureModel.fromMap).toList();
  }

  Future<String> nextFactureNumber() => _nextDocumentNumber('factures', 'FAC');

  Future<String> _nextDocumentNumber(String table, String prefix) async {
    final year = DateTime.now().year;
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT MAX(CAST(substr(numero, 10) AS INTEGER)) AS maximum FROM $table WHERE numero LIKE ?',
      ['$prefix-$year-%'],
    );
    final next = ((rows.first['maximum'] as int?) ?? 0) + 1;
    return '$prefix-$year-${next.toString().padLeft(3, '0')}';
  }

  Future<void> _saveLines(Database db, String table, String foreignKey, int documentId, String json) async {
    final decoded = json.isEmpty ? const <dynamic>[] : jsonDecode(json) as List<dynamic>;
    for (final item in decoded) {
      final line = item as Map<String, dynamic>;
      await db.insert(table, {
        foreignKey: documentId,
        'prestationId': line['prestationId'],
        'description': line['description'],
        'quantite': line['quantite'],
        'prixUnitaire': line['prixUnitaire'],
        'total': line['total'],
      });
    }
  }

  Future<List<FactureModel>> facturesByClient(int clientId) async {
    final db = await database;
    final rows = await db.query('factures', where: 'clientId = ?', whereArgs: [clientId], orderBy: 'date DESC');
    return rows.map(FactureModel.fromMap).toList();
  }
}
