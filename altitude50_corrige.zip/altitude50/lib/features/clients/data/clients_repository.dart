import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';

class ClientsRepository {
  Future<List<ClientModel>> loadClients() => AppDatabase.instance.clients();

  Future<ClientModel> addClient(ClientModel client) => AppDatabase.instance.insertClient(client);

  Future<void> updateClient(ClientModel client) async {
    await AppDatabase.instance.updateClient(client);
  }

  Future<void> deleteClient(int id) async {
    await AppDatabase.instance.deleteClient(id);
  }

  Future<List<ClientModel>> searchClients(String query) => AppDatabase.instance.searchClients(query);
}
