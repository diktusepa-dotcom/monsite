import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:flutter/material.dart';

import '../../../../app/app.dart' show routeObserver;
import 'client_detail_screen.dart';
import 'client_form_screen.dart';

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});

  @override
  State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> with RouteAware {
  final _searchController = TextEditingController();
  late Future<List<ClientModel>> _clientsFuture;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() {
    final query = _searchController.text.trim();
    _clientsFuture = query.isEmpty
        ? AppDatabase.instance.clients()
        : AppDatabase.instance.searchClients(query);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route != null) routeObserver.subscribe(this, route);
  }

  @override
  void didPopNext() {
    // On revient sur l'écran Clients après fermeture d'une fenêtre au-dessus
    // (fiche client, formulaire…) : on rafraîchit systématiquement, sans se
    // fier uniquement à la valeur de retour de cette fenêtre.
    setState(_refresh);
  }

  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _openNewClient() async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const ClientFormScreen()),
    );
    if (saved == true && mounted) setState(_refresh);
  }

  Future<void> _openClient(ClientModel client) async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => ClientDetailScreen(client: client)),
    );
    if (changed == true && mounted) setState(_refresh);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Clients'),
        actions: [
          IconButton(
            onPressed: _openNewClient,
            icon: const Icon(Icons.person_add_alt_1_outlined),
            tooltip: 'Nouveau client',
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                controller: _searchController,
                onChanged: (_) => setState(_refresh),
                decoration: InputDecoration(
                  hintText: 'Rechercher un client',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _openNewClient,
                  icon: const Icon(Icons.add),
                  label: const Text('Nouveau client'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: FutureBuilder<List<ClientModel>>(
                  future: _clientsFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final clients = snapshot.data ?? const <ClientModel>[];
                    if (clients.isEmpty) return const Center(child: Text('Aucun client'));
                    return ListView.separated(
                      padding: const EdgeInsets.only(bottom: 8),
                      itemCount: clients.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final client = clients[index];
                        final clientKey = ValueKey('client_${client.id}');

                        return Card(
                          margin: EdgeInsets.zero,
                          clipBehavior: Clip.antiAlias,
                          child: InkWell(
                            key: clientKey,
                            onTap: () => _openClient(client),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                                leading: CircleAvatar(
                                  backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                                  child: Text(
                                    client.nom.substring(0, 1).toUpperCase(),
                                    style: TextStyle(color: Theme.of(context).colorScheme.onPrimaryContainer),
                                  ),
                                ),
                                title: Text('${client.prenom} ${client.nom}'),
                                subtitle: Text('${client.ville} • ${client.telephone}'),
                                trailing: const Icon(Icons.chevron_right),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
