import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/devis_model.dart';
import 'package:altitude50/data/models/facture_model.dart';
import 'package:altitude50/data/models/intervention_model.dart';
import 'package:flutter/material.dart';

import '../../../interventions/presentation/screens/intervention_form_screen.dart';
import '../../../factures/presentation/screens/facture_form_screen.dart';
import '../../../devis/presentation/screens/devis_form_screen.dart';
import 'client_form_screen.dart';

class ClientDetailScreen extends StatefulWidget {
  const ClientDetailScreen({super.key, required this.client});

  final ClientModel client;

  @override
  State<ClientDetailScreen> createState() => _ClientDetailScreenState();
}

class _ClientDetailScreenState extends State<ClientDetailScreen> {
  late Future<List<InterventionModel>> _interventionsFuture;
  late Future<List<DevisModel>> _devisFuture;
  late Future<List<FactureModel>> _facturesFuture;

  @override
  void initState() {
    super.initState();
    _interventionsFuture = AppDatabase.instance.interventionsByClient(widget.client.id!);
    _devisFuture = AppDatabase.instance.devisByClient(widget.client.id!);
    _facturesFuture = AppDatabase.instance.facturesByClient(widget.client.id!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.client.prenom} ${widget.client.nom}'),
        actions: [
          IconButton(
            onPressed: () async {
              final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => ClientFormScreen(client: widget.client)));
              if (saved == true && context.mounted) Navigator.of(context).pop(true);
            },
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'Modifier le client',
          ),
          IconButton(
            onPressed: () async {
              final confirmed = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(title: const Text('Supprimer le client ?'), actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Supprimer'))]));
              if (confirmed == true) { await AppDatabase.instance.deleteClient(widget.client.id!); if (context.mounted) Navigator.of(context).pop(true); }
            },
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Supprimer le client',
          ),
        ],
      ),
      body: FutureBuilder<List<InterventionModel>>(
        future: _interventionsFuture,
        builder: (context, snapshot) {
          final interventions = snapshot.data ?? const <InterventionModel>[];
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.client.nom, style: Theme.of(context).textTheme.headlineSmall),
                          const SizedBox(height: 8),
                          Text('${widget.client.prenom} • ${widget.client.telephone}'),
                          Text(widget.client.email),
                          const SizedBox(height: 8),
                          Text('${widget.client.adresse}, ${widget.client.codePostal} ${widget.client.ville}'),
                          Text('Créé le ${widget.client.dateCreation.split('T').first}'),
                          if (widget.client.notes.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text('Notes : ${widget.client.notes}'),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: () async {
                      await Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => InterventionFormScreen(client: widget.client)),
                      );
                      if (mounted) {
                        setState(() {
                          _interventionsFuture = AppDatabase.instance.interventionsByClient(widget.client.id!);
                        });
                      }
                    },
                    icon: const Icon(Icons.add_task_outlined),
                    label: const Text('Nouvelle intervention'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () async {
                      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => DevisFormScreen(client: widget.client)));
                      if (mounted) setState(() => _devisFuture = AppDatabase.instance.devisByClient(widget.client.id!));
                    },
                    icon: const Icon(Icons.description_outlined),
                    label: const Text('Nouveau devis'),
                  ),
                  const SizedBox(height: 20),
                  Text('Historique d’interventions', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  Expanded(
                    child: ListView(
                      children: [
                        if (interventions.isEmpty) const Text('Aucune intervention'),
                        ...interventions.map((intervention) => Card(
                              child: ListTile(
                                title: Text(intervention.appareil),
                                subtitle: Text('${intervention.date} • ${intervention.statut}'),
                                trailing: intervention.statut == 'Terminée'
                                    ? IconButton(
                                        icon: const Icon(Icons.receipt_long_outlined),
                                        tooltip: 'Créer la facture',
                                        onPressed: () async {
                                          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => FactureFormScreen(client: widget.client, intervention: intervention)));
                                          if (mounted) setState(() => _facturesFuture = AppDatabase.instance.facturesByClient(widget.client.id!));
                                        },
                                      )
                                    : Text('${intervention.total} €'),
                              ),
                            )),
                        const SizedBox(height: 16),
                        _HistorySection<DevisModel>(
                          title: 'Historique des devis',
                          future: _devisFuture,
                          emptyLabel: 'Aucun devis',
                          itemBuilder: (devis) => ListTile(
                            title: Text(devis.numero),
                            subtitle: Text('${devis.date} • ${devis.statut}'),
                            trailing: Text('${devis.total} €'),
                          ),
                        ),
                        _HistorySection<FactureModel>(
                          title: 'Historique des factures',
                          future: _facturesFuture,
                          emptyLabel: 'Aucune facture',
                          itemBuilder: (facture) => ListTile(
                            title: Text(facture.numero),
                            subtitle: Text('${facture.date} • ${facture.statutPaiement}'),
                            trailing: Text('${facture.total} €'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _HistorySection<T> extends StatelessWidget {
  const _HistorySection({required this.title, required this.future, required this.emptyLabel, required this.itemBuilder});

  final String title;
  final Future<List<T>> future;
  final String emptyLabel;
  final Widget Function(T item) itemBuilder;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<T>>(
      future: future,
      builder: (context, snapshot) {
        final items = snapshot.data ?? <T>[];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            if (items.isEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(emptyLabel)),
            ...items.map((item) => Card(child: itemBuilder(item))),
          ],
        );
      },
    );
  }
}
