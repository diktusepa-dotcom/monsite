import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:flutter/material.dart';

class ClientFormScreen extends StatefulWidget {
  const ClientFormScreen({super.key, this.client});

  final ClientModel? client;

  @override
  State<ClientFormScreen> createState() => _ClientFormScreenState();
}

class _ClientFormScreenState extends State<ClientFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nomController;
  late final TextEditingController _prenomController;
  late final TextEditingController _telephoneController;
  late final TextEditingController _emailController;
  late final TextEditingController _adresseController;
  late final TextEditingController _codePostalController;
  late final TextEditingController _villeController;
  late final TextEditingController _notesController;

  @override
  void initState() {
    super.initState();
    final client = widget.client;
    _nomController = TextEditingController(text: client?.nom ?? '');
    _prenomController = TextEditingController(text: client?.prenom ?? '');
    _telephoneController = TextEditingController(text: client?.telephone ?? '');
    _emailController = TextEditingController(text: client?.email ?? '');
    _adresseController = TextEditingController(text: client?.adresse ?? '');
    _codePostalController = TextEditingController(text: client?.codePostal ?? '');
    _villeController = TextEditingController(text: client?.ville ?? '');
    _notesController = TextEditingController(text: client?.notes ?? '');
  }

  @override
  void dispose() {
    _nomController.dispose();
    _prenomController.dispose();
    _telephoneController.dispose();
    _emailController.dispose();
    _adresseController.dispose();
    _codePostalController.dispose();
    _villeController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final client = ClientModel(
      id: widget.client?.id,
      nom: _nomController.text.trim(),
      prenom: _prenomController.text.trim(),
      telephone: _telephoneController.text.trim(),
      email: _emailController.text.trim(),
      adresse: _adresseController.text.trim(),
      codePostal: _codePostalController.text.trim(),
      ville: _villeController.text.trim(),
      notes: _notesController.text.trim(),
      dateCreation: widget.client?.dateCreation ?? DateTime.now().toIso8601String(),
    );
    if (widget.client == null) {
      await AppDatabase.instance.insertClient(client);
    } else {
      await AppDatabase.instance.updateClient(client);
    }
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Champ requis' : null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.client == null ? 'Nouveau client' : 'Modifier le client')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(controller: _nomController, decoration: const InputDecoration(labelText: 'Nom'), validator: _required),
            const SizedBox(height: 12),
            TextFormField(controller: _prenomController, decoration: const InputDecoration(labelText: 'Prénom'), validator: _required),
            const SizedBox(height: 12),
            TextFormField(controller: _telephoneController, decoration: const InputDecoration(labelText: 'Téléphone'), validator: _required, keyboardType: TextInputType.phone),
            const SizedBox(height: 12),
            TextFormField(controller: _emailController, decoration: const InputDecoration(labelText: 'E-mail'), keyboardType: TextInputType.emailAddress),
            const SizedBox(height: 12),
            TextFormField(controller: _adresseController, decoration: const InputDecoration(labelText: 'Adresse'), validator: _required),
            const SizedBox(height: 12),
            TextFormField(controller: _codePostalController, decoration: const InputDecoration(labelText: 'Code postal'), validator: _required, keyboardType: TextInputType.number),
            const SizedBox(height: 12),
            TextFormField(controller: _villeController, decoration: const InputDecoration(labelText: 'Ville'), validator: _required),
            const SizedBox(height: 12),
            TextFormField(controller: _notesController, decoration: const InputDecoration(labelText: 'Notes'), maxLines: 3),
            const SizedBox(height: 24),
            FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer')),
          ],
        ),
      ),
    );
  }
}
