import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/intervention_model.dart';
import 'package:flutter/material.dart';

class AgendaScreen extends StatefulWidget {
  const AgendaScreen({super.key});

  @override
  State<AgendaScreen> createState() => _AgendaScreenState();
}

class _AgendaScreenState extends State<AgendaScreen> {
  late Future<List<InterventionModel>> _future;

  @override
  void initState() { super.initState(); _future = AppDatabase.instance.interventions(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Agenda')),
    body: FutureBuilder<List<InterventionModel>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        final items = snapshot.data ?? const <InterventionModel>[];
        return items.isEmpty ? const Center(child: Text('Aucun rendez-vous')) : ListView.separated(
          padding: const EdgeInsets.all(16), itemCount: items.length, separatorBuilder: (_, _) => const SizedBox(height: 12),
          itemBuilder: (context, index) { final item = items[index]; return Card(child: ListTile(leading: const Icon(Icons.access_time), title: Text(item.appareil), subtitle: Text('${item.date} • ${item.heure} • ${item.statut}'), trailing: Text('${item.total} €'))); },
        );
      },
    ),
  );
}
