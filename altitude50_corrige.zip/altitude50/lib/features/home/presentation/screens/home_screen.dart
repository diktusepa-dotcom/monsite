import 'package:altitude50/data/database/app_database.dart';
import 'package:flutter/material.dart';

import '../../../clients/presentation/screens/client_form_screen.dart';
import '../../../clients/presentation/screens/clients_screen.dart';
import '../../../interventions/presentation/screens/intervention_form_screen.dart';
import '../../../interventions/presentation/screens/interventions_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, this.onClientCreated});

  final VoidCallback? onClientCreated;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<dynamic>> _summaryFuture;

  @override
  void initState() {
    super.initState();
    _summaryFuture = Future.wait<dynamic>([AppDatabase.instance.clients(), AppDatabase.instance.interventions()]);
  }

  Future<void> _open(BuildContext context, Widget screen) async {
    final result = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    if (result == true && context.mounted && screen is ClientFormScreen) {
      widget.onClientCreated?.call();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Alt'itude 50")),
      body: SafeArea(
        child: FutureBuilder(
          future: _summaryFuture,
          builder: (context, snapshot) {
            final clients = snapshot.data?[0].length ?? 0;
            final interventions = snapshot.data?[1].length ?? 0;
            return SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 960),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(width: 56, height: 56, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF14B8A6), Color(0xFF0F766E)]), borderRadius: BorderRadius.circular(18)), child: const Icon(Icons.terrain, color: Colors.white, size: 28)),
                      const SizedBox(width: 12),
                      Text('Votre activité', style: Theme.of(context).textTheme.headlineSmall),
                    ]),
                    const SizedBox(height: 20),
                    Row(children: [
                      Expanded(child: _MetricCard(title: 'Clients', value: '$clients', accent: const Color(0xFF2563EB))),
                      const SizedBox(width: 12),
                      Expanded(child: _MetricCard(title: 'Interventions', value: '$interventions', accent: const Color(0xFF14B8A6))),
                    ]),
                    const SizedBox(height: 20),
                    Text('Raccourcis', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 12),
                    Wrap(spacing: 12, runSpacing: 12, children: [
                      FilledButton.icon(onPressed: () => _open(context, const ClientFormScreen()), icon: const Icon(Icons.person_add_alt_1_outlined), label: const Text('Nouveau client')),
                      FilledButton.icon(onPressed: () => _open(context, const InterventionFormScreen()), icon: const Icon(Icons.build_circle_outlined), label: const Text('Nouvelle intervention')),
                      OutlinedButton.icon(onPressed: () => _open(context, const ClientsScreen()), icon: const Icon(Icons.people_outline), label: const Text('Clients')),
                      OutlinedButton.icon(onPressed: () => _open(context, const InterventionsScreen()), icon: const Icon(Icons.list_alt_outlined), label: const Text('Interventions')),
                    ]),
                    const SizedBox(height: 24),
                    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Données enregistrées', style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 12),
                      const Text('Les clients et interventions apparaîtront ici après leur création.'),
                    ]))),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.title, required this.value, required this.accent});
  final String title;
  final String value;
  final Color accent;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(Icons.trending_up, color: accent),
      const SizedBox(height: 12),
      Text(title),
      const SizedBox(height: 6),
      Text(value, style: Theme.of(context).textTheme.headlineSmall),
    ]),
  );
}
