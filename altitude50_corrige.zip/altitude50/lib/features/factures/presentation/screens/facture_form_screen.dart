import 'dart:convert';

import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/devis_model.dart';
import 'package:altitude50/data/models/facture_model.dart';
import 'package:altitude50/data/models/intervention_model.dart';
import 'package:altitude50/data/models/prestation_model.dart';
import 'package:flutter/material.dart';

class FactureFormScreen extends StatefulWidget {
  const FactureFormScreen({super.key, this.client, this.intervention, this.devis});

  final ClientModel? client;
  final InterventionModel? intervention;
  final DevisModel? devis;

  @override
  State<FactureFormScreen> createState() => _FactureFormScreenState();
}

class _FactureFormScreenState extends State<FactureFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _quantity;
  late final TextEditingController _travel;
  late final TextEditingController _discount;
  late final TextEditingController _notes;
  ClientModel? _client;
  PrestationModel? _prestation;
  String _payment = 'Carte';
  String _status = 'Brouillon';

  @override
  void initState() {
    super.initState();
    _client = widget.client;
    final line = _firstLine;
    _quantity = TextEditingController(text: '${line?['quantite'] ?? 1}');
    _travel = TextEditingController(text: '${widget.devis?.deplacement ?? widget.intervention?.fraisDeplacement ?? 0}');
    _discount = TextEditingController(text: '${widget.devis?.remise ?? 0}');
    _notes = TextEditingController(text: widget.devis?.notes ?? '');
  }

  Map<String, dynamic>? get _firstLine {
    final json = widget.devis?.lignes;
    if (json == null || json.isEmpty) return null;
    final lines = jsonDecode(json) as List<dynamic>;
    return lines.isEmpty ? null : lines.first as Map<String, dynamic>;
  }

  @override
  void dispose() { _quantity.dispose(); _travel.dispose(); _discount.dispose(); _notes.dispose(); super.dispose(); }

  int get _unitPrice => _prestation?.prix ?? (_firstLine?['prixUnitaire'] as int? ?? widget.intervention?.prixPrestation ?? 0);
  int get _total => _unitPrice * (int.tryParse(_quantity.text) ?? 1) + (int.tryParse(_travel.text) ?? 0) - (int.tryParse(_discount.text) ?? 0);

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _client == null || (_prestation == null && _firstLine == null && widget.intervention == null)) return;
    final quantity = int.tryParse(_quantity.text) ?? 1;
    final description = _prestation?.nom ?? _firstLine?['description'] ?? widget.intervention?.appareil ?? 'Prestation';
    final model = FactureModel(
      id: null, clientId: _client!.id!, numero: '', date: DateTime.now().toIso8601String().split('T').first,
      interventionId: widget.intervention?.id ?? 0, devisId: widget.devis?.id ?? 0,
      lignes: jsonEncode([{'prestationId': _prestation?.id ?? _firstLine?['prestationId'], 'description': description, 'quantite': quantity, 'prixUnitaire': _unitPrice, 'total': quantity * _unitPrice}]),
      deplacement: int.tryParse(_travel.text) ?? 0, remise: int.tryParse(_discount.text) ?? 0, total: _total,
      statutPaiement: _status, modePaiement: _payment,
    );
    await AppDatabase.instance.insertFacture(model);
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nouvelle facture')),
    body: FutureBuilder<List<ClientModel>>(
      future: AppDatabase.instance.clients(),
      builder: (context, clientsSnapshot) => FutureBuilder<List<PrestationModel>>(
        future: AppDatabase.instance.prestations(),
        builder: (context, prestationsSnapshot) {
          final clients = clientsSnapshot.data ?? const <ClientModel>[];
          final prestations = prestationsSnapshot.data ?? const <PrestationModel>[];
          return Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(16), children: [
            DropdownButtonFormField<ClientModel>(initialValue: _client, items: clients.map((c) => DropdownMenuItem(value: c, child: Text('${c.prenom} ${c.nom}'))).toList(), onChanged: widget.client != null ? null : (v) => setState(() => _client = v), decoration: const InputDecoration(labelText: 'Client'), validator: (_) => _client == null ? 'Sélectionnez un client' : null),
            const SizedBox(height: 12),
            if (widget.intervention == null && widget.devis == null) DropdownButtonFormField<PrestationModel>(initialValue: _prestation, items: prestations.map((p) => DropdownMenuItem(value: p, child: Text(p.nom))).toList(), onChanged: (v) => setState(() => _prestation = v), decoration: const InputDecoration(labelText: 'Prestation'), validator: (_) => _prestation == null ? 'Sélectionnez une prestation' : null),
            Text('Prix unitaire : $_unitPrice €'),
            TextFormField(controller: _quantity, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Quantité')),
            TextFormField(controller: _travel, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Déplacement (€)')),
            TextFormField(controller: _discount, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Remise (€)')),
            DropdownButtonFormField<String>(initialValue: _payment, items: ['Espèces', 'Carte', 'Virement'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setState(() => _payment = v ?? 'Carte'), decoration: const InputDecoration(labelText: 'Mode de paiement')),
            DropdownButtonFormField<String>(initialValue: _status, items: ['Brouillon', 'Envoyée', 'Payée', 'Impayée', 'Annulée'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setState(() => _status = v ?? 'Brouillon'), decoration: const InputDecoration(labelText: 'Statut de paiement')),
            TextFormField(controller: _notes, maxLines: 3, decoration: const InputDecoration(labelText: 'Notes')),
            const SizedBox(height: 18), Text('Total : $_total €', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 18), FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer')),
          ]));
        },
      ),
    ),
  );
}
