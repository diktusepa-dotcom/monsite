import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/facture_model.dart';
import 'package:altitude50/data/services/document_pdf_service.dart';
import 'package:flutter/material.dart';

import '../../../../app/app.dart' show routeObserver;
import 'facture_form_screen.dart';

class FacturesScreen extends StatefulWidget {
  const FacturesScreen({super.key});

  @override
  State<FacturesScreen> createState() => _FacturesScreenState();
}

class _FacturesScreenState extends State<FacturesScreen> with RouteAware {
  late Future<List<FactureModel>> _future;

  @override
  void initState() { super.initState(); _reload(); }
  void _reload() { _future = AppDatabase.instance.factures(); }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route != null) routeObserver.subscribe(this, route);
  }

  @override
  void didPopNext() => setState(_reload);

  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    super.dispose();
  }

  Future<void> _newInvoice() async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const FactureFormScreen()));
    if (saved == true && mounted) setState(_reload);
  }

  Future<ClientModel?> _client(FactureModel facture) => AppDatabase.instance.clientById(facture.clientId);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Factures'), actions: [FilledButton.icon(onPressed: _newInvoice, icon: const Icon(Icons.add), label: const Text('Nouvelle facture'))]),
    body: FutureBuilder<List<FactureModel>>(
      future: _future,
      builder: (context, snapshot) {
        final items = snapshot.data ?? const <FactureModel>[];
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (items.isEmpty) return const Center(child: Text('Aucune facture'));
        return ListView.separated(
          padding: const EdgeInsets.all(16), itemCount: items.length, separatorBuilder: (_, _) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final facture = items[index];
            return Card(child: ListTile(
              title: Text(facture.numero), subtitle: Text('${facture.date} • ${facture.total} € • ${facture.statutPaiement}'),
              trailing: IconButton(icon: const Icon(Icons.picture_as_pdf_outlined), tooltip: 'Générer PDF', onPressed: () async { final client = await _client(facture); if (client != null && context.mounted) await DocumentPdfService.shareFacture(facture, client); }),
            ));
          },
        );
      },
    ),
  );
}
