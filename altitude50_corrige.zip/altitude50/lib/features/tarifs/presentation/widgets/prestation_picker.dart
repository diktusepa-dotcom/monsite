import 'package:altitude50/data/models/prestation_model.dart';
import 'package:flutter/material.dart';

/// Ouvre une recherche plein écran pour choisir une prestation, avec le prix
/// toujours visible à côté de chaque ligne. Retourne la prestation choisie,
/// ou null si l'utilisateur annule.
Future<PrestationModel?> pickPrestation(
  BuildContext context,
  List<PrestationModel> prestations,
) {
  return Navigator.of(context).push<PrestationModel>(
    MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => _PrestationPickerScreen(prestations: prestations),
    ),
  );
}

class _PrestationPickerScreen extends StatefulWidget {
  const _PrestationPickerScreen({required this.prestations});

  final List<PrestationModel> prestations;

  @override
  State<_PrestationPickerScreen> createState() => _PrestationPickerScreenState();
}

class _PrestationPickerScreenState extends State<_PrestationPickerScreen> {
  final _searchController = TextEditingController();
  String _query = '';
  String? _openCategory;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Map<String, List<PrestationModel>> _groupedBy(List<PrestationModel> items) {
    final grouped = <String, List<PrestationModel>>{};
    for (final prestation in items) {
      grouped.putIfAbsent(prestation.categorie, () => []).add(prestation);
    }
    return grouped;
  }

  @override
  Widget build(BuildContext context) {
    final query = _query.trim().toLowerCase();
    final isSearching = query.isNotEmpty;

    if (isSearching) {
      final filtered = widget.prestations
          .where((p) => p.nom.toLowerCase().contains(query) || p.categorie.toLowerCase().contains(query))
          .toList();
      final grouped = _groupedBy(filtered);
      return Scaffold(
        appBar: _searchAppBar(),
        body: filtered.isEmpty
            ? const Center(child: Text('Aucune prestation trouvée'))
            : ListView(
                children: [
                  for (final entry in grouped.entries) ...[
                    _CategoryHeader(entry.key),
                    for (final prestation in entry.value) _PrestationRow(prestation, onTap: () => Navigator.of(context).pop(prestation)),
                  ],
                ],
              ),
      );
    }

    if (_openCategory != null) {
      final items = widget.prestations.where((p) => p.categorie == _openCategory).toList();
      return Scaffold(
        appBar: AppBar(
          leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => setState(() => _openCategory = null)),
          title: Text(_openCategory!),
        ),
        body: ListView(
          children: [for (final prestation in items) _PrestationRow(prestation, onTap: () => Navigator.of(context).pop(prestation))],
        ),
      );
    }

    final grouped = _groupedBy(widget.prestations);
    return Scaffold(
      appBar: _searchAppBar(),
      body: ListView(
        children: [
          for (final entry in grouped.entries)
            ListTile(
              title: Text(entry.key),
              subtitle: Text('${entry.value.length} prestation(s)'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => setState(() => _openCategory = entry.key),
            ),
        ],
      ),
    );
  }

  AppBar _searchAppBar() => AppBar(
    title: TextField(
      controller: _searchController,
      onChanged: (value) => setState(() => _query = value),
      decoration: const InputDecoration(
        hintText: 'Ou rechercher un mot-clé…',
        border: InputBorder.none,
      ),
    ),
  );
}

class _CategoryHeader extends StatelessWidget {
  const _CategoryHeader(this.title);
  final String title;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
    child: Text(title, style: Theme.of(context).textTheme.labelLarge?.copyWith(color: Theme.of(context).colorScheme.primary)),
  );
}

class _PrestationRow extends StatelessWidget {
  const _PrestationRow(this.prestation, {required this.onTap});
  final PrestationModel prestation;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
    title: Text(prestation.nom),
    trailing: Text(
      prestation.prix == 0 ? 'Sur devis' : '${prestation.prix} €',
      style: Theme.of(context).textTheme.titleMedium,
    ),
    onTap: onTap,
  );
}

/// Champ de formulaire tappable affichant la prestation choisie (nom + prix)
/// et ouvrant [pickPrestation] au tap, au lieu d'un long menu déroulant.
class PrestationPickerField extends StatelessWidget {
  const PrestationPickerField({
    super.key,
    required this.prestations,
    required this.selected,
    required this.onSelected,
    this.errorText,
  });

  final List<PrestationModel> prestations;
  final PrestationModel? selected;
  final ValueChanged<PrestationModel> onSelected;
  final String? errorText;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(4),
      onTap: prestations.isEmpty
          ? null
          : () async {
              final picked = await pickPrestation(context, prestations);
              if (picked != null) onSelected(picked);
            },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: 'Prestation',
          errorText: errorText,
          suffixIcon: const Icon(Icons.search),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                selected == null ? 'Sélectionner une prestation' : selected!.nom,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (selected != null)
              Text(
                selected!.prix == 0 ? 'Sur devis' : '${selected!.prix} €',
                style: Theme.of(context).textTheme.titleMedium,
              ),
          ],
        ),
      ),
    );
  }
}
