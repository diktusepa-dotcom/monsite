import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/prestation_model.dart';
import 'package:flutter/material.dart';

class TarifsScreen extends StatefulWidget {
  const TarifsScreen({super.key});

  @override
  State<TarifsScreen> createState() => _TarifsScreenState();
}

class _TarifsScreenState extends State<TarifsScreen> {
  final _searchController = TextEditingController();
  late Future<List<PrestationModel>> _prestationsFuture;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _prestationsFuture = AppDatabase.instance.prestations();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tarifs')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                controller: _searchController,
                onChanged: (value) => setState(() => _query = value),
                decoration: InputDecoration(
                  hintText: 'Rechercher une prestation',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () => setState(() {
                            _searchController.clear();
                            _query = '';
                          }),
                        ),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: FutureBuilder<List<PrestationModel>>(
                  future: _prestationsFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final prestations = snapshot.data ?? const <PrestationModel>[];
                    if (prestations.isEmpty) return const Center(child: Text('Aucune prestation'));

                    final query = _query.trim().toLowerCase();
                    final filtered = query.isEmpty
                        ? prestations
                        : prestations
                            .where((p) => p.nom.toLowerCase().contains(query) || p.categorie.toLowerCase().contains(query))
                            .toList();

                    if (filtered.isEmpty) return const Center(child: Text('Aucun résultat'));

                    final categories = <String, List<PrestationModel>>{};
                    for (final prestation in filtered) {
                      categories.putIfAbsent(prestation.categorie, () => []).add(prestation);
                    }

                    // Recherche active : tout est déplié pour voir le prix immédiatement.
                    if (query.isNotEmpty) {
                      return ListView(
                        children: [
                          for (final entry in categories.entries) ...[
                            Padding(
                              padding: const EdgeInsets.fromLTRB(4, 12, 4, 4),
                              child: Text(
                                entry.key,
                                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                                      color: Theme.of(context).colorScheme.primary,
                                    ),
                              ),
                            ),
                            for (final prestation in entry.value)
                              Card(
                                margin: const EdgeInsets.only(bottom: 6),
                                child: ListTile(
                                  title: Text(prestation.nom),
                                  trailing: Text(
                                    prestation.prix == 0 ? 'Sur devis' : '${prestation.prix} €',
                                    style: Theme.of(context).textTheme.titleMedium,
                                  ),
                                ),
                              ),
                          ],
                        ],
                      );
                    }

                    return ListView(
                      children: categories.entries
                          .map((entry) => Card(
                                margin: const EdgeInsets.only(bottom: 12),
                                child: ExpansionTile(
                                  title: Text(entry.key),
                                  subtitle: Text('${entry.value.length} prestation(s)'),
                                  children: entry.value
                                      .map((prestation) => ListTile(
                                            title: Text(prestation.nom),
                                            trailing: Text(prestation.prix == 0 ? 'Sur devis' : '${prestation.prix} €'),
                                          ))
                                      .toList(),
                                ),
                              ))
                          .toList(),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
