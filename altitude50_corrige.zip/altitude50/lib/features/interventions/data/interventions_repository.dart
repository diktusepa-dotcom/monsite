import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/intervention_model.dart';
import 'package:altitude50/data/models/prestation_model.dart';

class InterventionsRepository {
  Future<List<PrestationModel>> loadPrestations() => AppDatabase.instance.prestations();

  Future<PrestationModel> addPrestation(PrestationModel prestation) => AppDatabase.instance.insertPrestation(prestation);

  Future<List<InterventionModel>> loadByClient(int clientId) => AppDatabase.instance.interventionsByClient(clientId);

  Future<InterventionModel> saveIntervention(InterventionModel intervention) => AppDatabase.instance.insertIntervention(intervention);

  Future<void> updateIntervention(InterventionModel intervention) async {
    await AppDatabase.instance.updateIntervention(intervention);
  }
}
