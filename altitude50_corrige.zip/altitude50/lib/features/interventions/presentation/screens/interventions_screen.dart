import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/intervention_model.dart';
import 'package:flutter/material.dart';

import 'intervention_form_screen.dart';

class InterventionsScreen extends StatefulWidget {
  const InterventionsScreen({super.key});

  @override
  State<InterventionsScreen> createState() => _InterventionsScreenState();
}

class _InterventionsScreenState extends State<InterventionsScreen> {
  late Future<List<InterventionModel>> _future;
  String _filter = 'Toutes';

  @override
  void initState() { super.initState(); _reload(); }
  void _reload() { _future = AppDatabase.instance.interventions(); }

  Future<void> _newIntervention() async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const InterventionFormScreen()));
    if (saved == true && mounted) setState(_reload);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Interventions'), actions: [FilledButton.icon(onPressed: _newIntervention, icon: const Icon(Icons.add), label: const Text('Nouvelle'))]),
    body: FutureBuilder<List<InterventionModel>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        final all = snapshot.data ?? const <InterventionModel>[];
        final items = _filter == 'Toutes' ? all : all.where((item) => item.statut == _filter).toList();
        return Column(children: [
          SingleChildScrollView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.all(16), child: SegmentedButton<String>(segments: const [ButtonSegment(value: 'Toutes', label: Text('Toutes')), ButtonSegment(value: 'À venir', label: Text('À venir')), ButtonSegment(value: 'En cours', label: Text('En cours')), ButtonSegment(value: 'Terminée', label: Text('Terminées')), ButtonSegment(value: 'Annulée', label: Text('Annulées'))], selected: {_filter}, onSelectionChanged: (value) => setState(() => _filter = value.first))),
          Expanded(child: items.isEmpty ? const Center(child: Text('Aucune intervention')) : ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 16), itemCount: items.length, separatorBuilder: (_, _) => const SizedBox(height: 12), itemBuilder: (context, index) { final item = items[index]; return Card(child: ListTile(leading: const Icon(Icons.build_circle_outlined), title: Text(item.appareil), subtitle: Text('${item.date} • ${item.statut} • ${item.total} €'))); })),
        ]);
      },
    ),
  );
}
