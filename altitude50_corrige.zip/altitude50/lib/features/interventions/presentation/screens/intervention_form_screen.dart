import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/intervention_model.dart';
import 'package:altitude50/data/models/prestation_model.dart';
import 'package:flutter/material.dart';

import '../../../tarifs/presentation/widgets/prestation_picker.dart';

class InterventionFormScreen extends StatefulWidget {
  const InterventionFormScreen({super.key, this.client, this.intervention});

  final ClientModel? client;
  final InterventionModel? intervention;

  @override
  State<InterventionFormScreen> createState() => _InterventionFormScreenState();
}

class _InterventionFormScreenState extends State<InterventionFormScreen> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _appareilController;
  late final TextEditingController _marqueController;
  late final TextEditingController _modeleController;
  late final TextEditingController _problemeController;
  late final TextEditingController _diagnosticController;
  late final TextEditingController _travailController;
  late final TextEditingController _notesController;
  late final TextEditingController _distanceController;
  late final TextEditingController _fraisController;

  final List<String> _statuts = ['À venir', 'En cours', 'Terminée', 'Annulée'];
  final List<String> _modesPaiement = ['Espèces', 'Carte', 'Virement'];

  int? _selectedClientId;
  int? _selectedPrestationId;
  Future<List<PrestationModel>>? _prestationsFuture;
  String _selectedStatut = 'À venir';
  String _selectedModePaiement = 'Carte';
  int _palier1Km = 10;
  int _palier1Prix = 10;
  int _palier2Km = 20;
  int _palier2Prix = 20;
  int _palier3Km = 30;
  int _palier3Prix = 30;
  int _distanceMax = 40;

  @override
  void initState() {
    super.initState();
    _prestationsFuture = AppDatabase.instance.prestations();
    _loadDeplacementSettings();
    _selectedClientId = widget.client?.id;
    _selectedPrestationId = widget.intervention?.prestationId;
    _appareilController = TextEditingController(text: widget.intervention?.appareil ?? '');
    _marqueController = TextEditingController(text: widget.intervention?.marque ?? '');
    _modeleController = TextEditingController(text: widget.intervention?.modele ?? '');
    _problemeController = TextEditingController(text: widget.intervention?.problemeSignale ?? '');
    _diagnosticController = TextEditingController(text: widget.intervention?.diagnostic ?? '');
    _travailController = TextEditingController(text: widget.intervention?.travailEffectue ?? '');
    _notesController = TextEditingController(text: widget.intervention?.notes ?? '');
    _distanceController = TextEditingController(text: '0');
    _fraisController = TextEditingController(text: (widget.intervention?.fraisDeplacement ?? 0).toString());

    if (widget.intervention != null) {
      _selectedStatut = widget.intervention!.statut;
      _selectedModePaiement = widget.intervention!.modePaiement;
    }
  }

  @override
  void dispose() {
    _appareilController.dispose();
    _marqueController.dispose();
    _modeleController.dispose();
    _problemeController.dispose();
    _diagnosticController.dispose();
    _travailController.dispose();
    _notesController.dispose();
    _distanceController.dispose();
    _fraisController.dispose();
    super.dispose();
  }

  Future<void> _loadDeplacementSettings() async {
    final values = await AppDatabase.instance.deplacementSettings();
    if (!mounted) return;
    setState(() {
      _palier1Km = values['palier1Km'] as int? ?? 10;
      _palier1Prix = values['palier1Prix'] as int? ?? 10;
      _palier2Km = values['palier2Km'] as int? ?? 20;
      _palier2Prix = values['palier2Prix'] as int? ?? 20;
      _palier3Km = values['palier3Km'] as int? ?? 30;
      _palier3Prix = values['palier3Prix'] as int? ?? 30;
      _distanceMax = values['distanceMax'] as int? ?? 40;
    });
  }

  int _distanceFee() {
    final distance = int.tryParse(_distanceController.text) ?? 0;
    if (distance > _distanceMax) return 0;
    if (distance > _palier3Km) return _palier3Prix;
    if (distance > _palier2Km) return _palier2Prix;
    if (distance > _palier1Km) return _palier1Prix;
    return 0;
  }

  String _distanceLabel() {
    final distance = int.tryParse(_distanceController.text) ?? 0;
    return distance > _distanceMax ? 'Sur devis' : '${_distanceFee()} €';
  }

  int _calculateTotal({PrestationModel? prestation}) {
    final prestationPrice = prestation?.prix ?? widget.intervention?.prixPrestation ?? 0;
    return prestationPrice + _distanceFee();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _selectedClientId == null || _selectedPrestationId == null) {
      return;
    }

    final heure = TimeOfDay.now().format(context);
    final selectedClient = (await AppDatabase.instance.clientById(_selectedClientId!)) ?? widget.client;
    final selectedPrestation = await AppDatabase.instance.prestationById(_selectedPrestationId!);
    if (selectedClient == null || selectedPrestation == null) return;

    final intervention = InterventionModel(
      id: widget.intervention?.id,
      clientId: selectedClient.id!,
      date: DateTime.now().toIso8601String().split('T').first,
      heure: heure,
      appareil: _appareilController.text,
      marque: _marqueController.text,
      modele: _modeleController.text,
      problemeSignale: _problemeController.text,
      diagnostic: _diagnosticController.text,
      travailEffectue: _travailController.text,
      prestationId: selectedPrestation.id!,
      prixPrestation: selectedPrestation.prix,
      fraisDeplacement: _distanceFee(),
      total: _calculateTotal(prestation: selectedPrestation),
      statut: _selectedStatut,
      modePaiement: _selectedModePaiement,
      notes: _notesController.text,
      dateCreation: DateTime.now().toIso8601String(),
    );

    if (widget.intervention == null) {
      await AppDatabase.instance.insertIntervention(intervention);
    } else {
      await AppDatabase.instance.updateIntervention(intervention);
    }

    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nouvelle intervention')),
      body: SafeArea(
        child: FutureBuilder<List<ClientModel>>(
          future: AppDatabase.instance.clients(),
          builder: (context, clientSnapshot) {
            final clients = clientSnapshot.data ?? const <ClientModel>[];
            ClientModel? selectedClient;
            for (final client in clients) {
              if (client.id == _selectedClientId) {
                selectedClient = client;
                break;
              }
            }
            selectedClient ??= widget.client;
            return FutureBuilder<List<PrestationModel>>(
              future: _prestationsFuture,
              builder: (context, prestationSnapshot) {
                final prestations = prestationSnapshot.data ?? const <PrestationModel>[];
                PrestationModel? selectedPrestation;
                for (final prestation in prestations) {
                  if (prestation.id == _selectedPrestationId) {
                    selectedPrestation = prestation;
                    break;
                  }
                }
                if (selectedPrestation == null && widget.intervention != null) {
                  for (final prestation in prestations) {
                    if (prestation.id == widget.intervention!.prestationId) {
                      selectedPrestation = prestation;
                      break;
                    }
                  }
                }
                return Form(
                  key: _formKey,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      DropdownButtonFormField<int>(
                        initialValue: selectedClient?.id ?? _selectedClientId,
                        isExpanded: true,
                        items: clients.map((client) {
                          return DropdownMenuItem<int>(
                            value: client.id,
                            child: Text('${client.prenom} ${client.nom}'),
                          );
                        }).toList(),
                        onChanged: (clientId) => setState(() => _selectedClientId = clientId),
                        decoration: const InputDecoration(labelText: 'Client'),
                      ),
                      const SizedBox(height: 12),
                      PrestationPickerField(
                        prestations: prestations,
                        selected: selectedPrestation,
                        onSelected: (p) => setState(() => _selectedPrestationId = p.id),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _appareilController,
                        decoration: const InputDecoration(labelText: 'Appareil'),
                        validator: (value) => value == null || value.isEmpty ? 'Champ requis' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _marqueController,
                        decoration: const InputDecoration(labelText: 'Marque'),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _modeleController,
                        decoration: const InputDecoration(labelText: 'Modèle'),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _problemeController,
                        maxLines: 2,
                        decoration: const InputDecoration(labelText: 'Problème signalé'),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _diagnosticController,
                        maxLines: 2,
                        decoration: const InputDecoration(labelText: 'Diagnostic'),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _travailController,
                        maxLines: 2,
                        decoration: const InputDecoration(labelText: 'Travail effectué'),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _distanceController,
                        keyboardType: TextInputType.number,
                        onChanged: (_) => setState(() {}),
                        decoration: const InputDecoration(labelText: 'Distance (km)'),
                        validator: (value) {
                          final distance = int.tryParse(value ?? '');
                          return distance == null || distance < 0 ? 'Distance invalide' : null;
                        },
                      ),
                      const SizedBox(height: 12),
                      InputDecorator(
                        decoration: const InputDecoration(labelText: 'Prix de la prestation'),
                        child: Text('${selectedPrestation?.prix ?? 0} €'),
                      ),
                      const SizedBox(height: 12),
                      InputDecorator(
                        decoration: const InputDecoration(labelText: 'Frais de déplacement'),
                        child: Text(_distanceLabel()),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _fraisController,
                        readOnly: true,
                        decoration: const InputDecoration(labelText: 'Frais calculés'),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        initialValue: _selectedStatut,
                        items: _statuts.map((value) => DropdownMenuItem(value: value, child: Text(value))).toList(),
                        onChanged: (value) => setState(() => _selectedStatut = value ?? 'À venir'),
                        decoration: const InputDecoration(labelText: 'Statut'),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        initialValue: _selectedModePaiement,
                        items: _modesPaiement.map((value) => DropdownMenuItem(value: value, child: Text(value))).toList(),
                        onChanged: (value) => setState(() => _selectedModePaiement = value ?? 'Carte'),
                        decoration: const InputDecoration(labelText: 'Mode de paiement'),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _notesController,
                        maxLines: 2,
                        decoration: const InputDecoration(labelText: 'Notes'),
                      ),
                      const SizedBox(height: 20),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Total : ${_calculateTotal(prestation: selectedPrestation)} €', style: Theme.of(context).textTheme.titleLarge),
                              const SizedBox(height: 8),
                              Text('Prestation : ${selectedPrestation?.prix ?? widget.intervention?.prixPrestation ?? 0} €'),
                              Text('Déplacement : ${_distanceLabel()}'),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      FilledButton.icon(
                        onPressed: _save,
                        icon: const Icon(Icons.save_outlined),
                        label: const Text('Enregistrer'),
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
