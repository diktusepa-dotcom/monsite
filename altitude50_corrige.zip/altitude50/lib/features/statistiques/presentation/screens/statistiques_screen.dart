import 'package:altitude50/data/database/app_database.dart';
import 'package:flutter/material.dart';

class StatistiquesScreen extends StatelessWidget {
  const StatistiquesScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Statistiques')),
    body: FutureBuilder(
      future: Future.wait([AppDatabase.instance.clients(), AppDatabase.instance.interventions(), AppDatabase.instance.devis(), AppDatabase.instance.factures()]),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        final clients = snapshot.data?[0].length ?? 0;
        final interventions = snapshot.data?[1].length ?? 0;
        final devis = snapshot.data?[2].length ?? 0;
        final factures = snapshot.data?[3].length ?? 0;
        return ListView(padding: const EdgeInsets.all(16), children: [
          _Stat(title: 'Clients', value: '$clients'),
          _Stat(title: 'Interventions', value: '$interventions'),
          _Stat(title: 'Devis', value: '$devis'),
          _Stat(title: 'Factures', value: '$factures'),
        ]);
      },
    ),
  );
}

class _Stat extends StatelessWidget {
  const _Stat({required this.title, required this.value});
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) => Card(child: ListTile(title: Text(title), trailing: Text(value, style: Theme.of(context).textTheme.headlineSmall)));
}
