import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/devis_model.dart';
import 'package:altitude50/data/services/document_pdf_service.dart';
import 'package:flutter/material.dart';

import '../../../../app/app.dart' show routeObserver;
import '../../../factures/presentation/screens/facture_form_screen.dart';
import 'devis_form_screen.dart';

class DevisScreen extends StatefulWidget {
  const DevisScreen({super.key});

  @override
  State<DevisScreen> createState() => _DevisScreenState();
}

class _DevisScreenState extends State<DevisScreen> with RouteAware {
  late Future<List<DevisModel>> _future;

  @override
  void initState() { super.initState(); _reload(); }
  void _reload() { _future = AppDatabase.instance.devis(); }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route != null) routeObserver.subscribe(this, route);
  }

  @override
  void didPopNext() => setState(_reload);

  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    super.dispose();
  }

  Future<void> _newQuote() async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const DevisFormScreen()));
    if (saved == true && mounted) setState(_reload);
  }

  Future<ClientModel?> _client(DevisModel devis) => AppDatabase.instance.clientById(devis.clientId);

  Future<void> _actions(DevisModel devis) async {
    final client = await _client(devis);
    if (!mounted || client == null) return;
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Modifier le statut'), onTap: () async {
          final status = await showDialog<String>(context: sheetContext, builder: (dialogContext) => SimpleDialog(title: const Text('Statut du devis'), children: ['Brouillon', 'Envoyé', 'Accepté', 'Refusé', 'Expiré'].map((status) => SimpleDialogOption(onPressed: () => Navigator.pop(dialogContext, status), child: Text(status))).toList()));
          if (status != null) { await AppDatabase.instance.updateDevis(devis.copyWith(statut: status)); if (mounted) setState(_reload); }
          if (sheetContext.mounted) Navigator.pop(sheetContext);
        }),
        if (devis.statut == 'Accepté') ListTile(leading: const Icon(Icons.receipt_long_outlined), title: const Text('Créer la facture'), onTap: () async {
          Navigator.pop(sheetContext);
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => FactureFormScreen(client: client, devis: devis)));
          if (mounted) setState(_reload);
        }),
      ])),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Devis'), actions: [FilledButton.icon(onPressed: _newQuote, icon: const Icon(Icons.add), label: const Text('Nouveau devis'))]),
    body: FutureBuilder<List<DevisModel>>(
      future: _future,
      builder: (context, snapshot) {
        final items = snapshot.data ?? const <DevisModel>[];
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (items.isEmpty) return const Center(child: Text('Aucun devis'));
        return ListView.separated(
          padding: const EdgeInsets.all(16), itemCount: items.length, separatorBuilder: (_, _) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final devis = items[index];
            return Card(child: ListTile(
              title: Text(devis.numero), subtitle: Text('${devis.date} • ${devis.total} € • ${devis.statut}'), onTap: () => _actions(devis),
              trailing: IconButton(icon: const Icon(Icons.picture_as_pdf_outlined), tooltip: 'Générer PDF', onPressed: () async { final client = await _client(devis); if (client != null && context.mounted) await DocumentPdfService.shareDevis(devis, client); }),
            ));
          },
        );
      },
    ),
  );
}
