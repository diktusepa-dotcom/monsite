import 'dart:convert';

import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/devis_model.dart';
import 'package:altitude50/data/models/prestation_model.dart';
import 'package:flutter/material.dart';

import '../../../tarifs/presentation/widgets/prestation_picker.dart';

class DevisFormScreen extends StatefulWidget {
  const DevisFormScreen({super.key, this.client});

  final ClientModel? client;

  @override
  State<DevisFormScreen> createState() => _DevisFormScreenState();
}

class _DevisFormScreenState extends State<DevisFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _quantity = TextEditingController(text: '1');
  final _travel = TextEditingController(text: '0');
  final _discount = TextEditingController(text: '0');
  final _notes = TextEditingController();
  int? _clientId;
  int? _prestationId;
  Future<List<PrestationModel>>? _prestationsFuture;
  String _status = 'Brouillon';

  @override
  void initState() {
    super.initState();
    _prestationsFuture = AppDatabase.instance.prestations();
    _clientId = widget.client?.id;
  }

  @override
  void dispose() { _quantity.dispose(); _travel.dispose(); _discount.dispose(); _notes.dispose(); super.dispose(); }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _clientId == null || _prestationId == null) return;
    final client = await AppDatabase.instance.clientById(_clientId!);
    final prestation = await AppDatabase.instance.prestationById(_prestationId!);
    if (client == null || prestation == null) return;
    final quantity = int.tryParse(_quantity.text) ?? 1;
    final unitPrice = prestation.prix;
    final subtotal = unitPrice * quantity;
    final total = subtotal + (int.tryParse(_travel.text) ?? 0) - (int.tryParse(_discount.text) ?? 0);
    final model = DevisModel(
      id: null, clientId: client.id!, numero: '', date: DateTime.now().toIso8601String().split('T').first,
      dateValidite: DateTime.now().add(const Duration(days: 30)).toIso8601String().split('T').first,
      lignes: jsonEncode([{'prestationId': prestation.id, 'description': prestation.nom, 'quantite': quantity, 'prixUnitaire': unitPrice, 'total': subtotal}]),
      deplacement: int.tryParse(_travel.text) ?? 0, remise: int.tryParse(_discount.text) ?? 0, total: total, statut: _status, notes: _notes.text.trim(),
    );
    await AppDatabase.instance.insertDevis(model);
    if (mounted) Navigator.of(context).pop(true);
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Champ requis' : null;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nouveau devis')),
    body: FutureBuilder<List<ClientModel>>(
      future: AppDatabase.instance.clients(),
      builder: (context, clientsSnapshot) => FutureBuilder<List<PrestationModel>>(
        future: _prestationsFuture,
        builder: (context, prestationsSnapshot) {
          final clients = clientsSnapshot.data ?? const <ClientModel>[];
          final prestations = prestationsSnapshot.data ?? const <PrestationModel>[];
          ClientModel? selectedClient;
          for (final client in clients) {
            if (client.id == _clientId) {
              selectedClient = client;
              break;
            }
          }
          PrestationModel? selectedPrestation;
          for (final prestation in prestations) {
            if (prestation.id == _prestationId) {
              selectedPrestation = prestation;
              break;
            }
          }
          final subtotal = (selectedPrestation?.prix ?? 0) * (int.tryParse(_quantity.text) ?? 0);
          final total = subtotal + (int.tryParse(_travel.text) ?? 0) - (int.tryParse(_discount.text) ?? 0);
          return Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(16), children: [
            DropdownButtonFormField<int>(initialValue: selectedClient?.id ?? _clientId, isExpanded: true, items: clients.map((c) => DropdownMenuItem<int>(value: c.id, child: Text('${c.prenom} ${c.nom}'))).toList(), onChanged: (v) => setState(() => _clientId = v), decoration: const InputDecoration(labelText: 'Client'), validator: (_) => _clientId == null ? 'Sélectionnez un client' : null),
            const SizedBox(height: 12),
            PrestationPickerField(
              prestations: prestations,
              selected: selectedPrestation,
              onSelected: (p) => setState(() => _prestationId = p.id),
            ),
            const SizedBox(height: 12),
            if (selectedPrestation != null) Text('Prix unitaire : ${selectedPrestation.prix} €'),
            TextFormField(controller: _quantity, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Quantité'), validator: _required),
            TextFormField(controller: _travel, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Déplacement (€)')),
            TextFormField(controller: _discount, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Remise (€)')),
            DropdownButtonFormField<String>(initialValue: _status, items: ['Brouillon', 'Envoyé', 'Accepté', 'Refusé', 'Expiré'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setState(() => _status = v ?? 'Brouillon'), decoration: const InputDecoration(labelText: 'Statut')),
            TextFormField(controller: _notes, maxLines: 3, decoration: const InputDecoration(labelText: 'Notes')),
            const SizedBox(height: 18),
            Text('Sous-total : $subtotal €'), Text('Total : $total €', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 18), FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer')),
          ]));
        },
      ),
    ),
  );
}
