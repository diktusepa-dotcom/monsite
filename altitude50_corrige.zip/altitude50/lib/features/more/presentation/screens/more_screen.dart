import 'package:altitude50/features/agenda/presentation/screens/agenda_screen.dart';
import 'package:altitude50/features/interventions/presentation/screens/interventions_screen.dart';
import 'package:altitude50/features/parametres/presentation/screens/parametres_screen.dart';
import 'package:altitude50/features/statistiques/presentation/screens/statistiques_screen.dart';
import 'package:altitude50/features/tarifs/presentation/screens/tarifs_screen.dart';
import 'package:flutter/material.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <_MoreItem>[
      _MoreItem(
        title: 'Interventions',
        icon: Icons.build_circle_outlined,
        color: const Color(0xFF0F766E),
        screen: const InterventionsScreen(),
      ),
      _MoreItem(
        title: 'Agenda',
        icon: Icons.calendar_month_outlined,
        color: const Color(0xFF7C3AED),
        screen: const AgendaScreen(),
      ),
      _MoreItem(
        title: 'Tarifs',
        icon: Icons.price_change_outlined,
        color: const Color(0xFF2563EB),
        screen: const TarifsScreen(),
      ),
      _MoreItem(
        title: 'Statistiques',
        icon: Icons.bar_chart_outlined,
        color: const Color(0xFF059669),
        screen: const StatistiquesScreen(),
      ),
      _MoreItem(
        title: 'Paramètres',
        icon: Icons.settings_outlined,
        color: const Color(0xFF475569),
        screen: const ParametresScreen(),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Plus'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth <= 0) {
                return const SizedBox.shrink();
              }
              return GridView.builder(
                itemCount: items.length,
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 220,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: 1.1,
                ),
                itemBuilder: (context, index) {
                  final item = items[index];
                  return Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => item.screen),
                        );
                      },
                      child: Ink(
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Theme.of(context).colorScheme.outlineVariant,
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: item.color.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Icon(item.icon, color: item.color, size: 28),
                              ),
                              const SizedBox(height: 18),
                              Text(
                                item.title,
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}

class _MoreItem {
  const _MoreItem({
    required this.title,
    required this.icon,
    required this.color,
    required this.screen,
  });

  final String title;
  final IconData icon;
  final Color color;
  final Widget screen;
}
