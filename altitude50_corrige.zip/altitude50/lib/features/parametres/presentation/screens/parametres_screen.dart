import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/features/tarifs/presentation/screens/tarifs_screen.dart';
import 'package:flutter/material.dart';

class ParametresScreen extends StatelessWidget {
  const ParametresScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: const Icon(Icons.business_outlined),
            title: const Text('Informations de l’entreprise'),
            subtitle: const Text('Nom, SIRET, coordonnées et TVA'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EntrepriseSettingsScreen())),
          ),
          const SizedBox(height: 12),
          ListTile(
            leading: const Icon(Icons.price_change_outlined),
            title: const Text('Tarifs'),
            subtitle: const Text('Prestations et règles de facturation'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TarifsScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.directions_car_outlined),
            title: const Text('Déplacements'),
            subtitle: const Text('Frais et zones de déplacement'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DeplacementSettingsScreen())),
          ),
        ],
      ),
    );
  }
}

class EntrepriseSettingsScreen extends StatefulWidget {
  const EntrepriseSettingsScreen({super.key});

  @override
  State<EntrepriseSettingsScreen> createState() => _EntrepriseSettingsScreenState();
}

class _EntrepriseSettingsScreenState extends State<EntrepriseSettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _controllers = <String, TextEditingController>{};

  @override
  void initState() {
    super.initState();
    for (final key in ['nom', 'adresse', 'telephone', 'email', 'siret', 'tva', 'informationsComplementaires']) {
      _controllers[key] = TextEditingController();
    }
    _load();
  }

  Future<void> _load() async {
    final values = await AppDatabase.instance.entrepriseSettings();
    for (final entry in _controllers.entries) {
      entry.value.text = values[entry.key] as String? ?? '';
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    await AppDatabase.instance.updateEntrepriseSettings({for (final entry in _controllers.entries) entry.key: entry.value.text.trim()});
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Entreprise')),
    body: Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(16), children: [
      for (final field in [
        ('nom', 'Nom de l’entreprise'), ('adresse', 'Adresse'), ('telephone', 'Téléphone'), ('email', 'E-mail'), ('siret', 'SIRET'), ('tva', 'Mention TVA'), ('informationsComplementaires', 'Informations complémentaires')
      ]) ...[
        TextFormField(controller: _controllers[field.$1], decoration: InputDecoration(labelText: field.$2), validator: field.$1 == 'nom' ? (value) => value == null || value.trim().isEmpty ? 'Champ requis' : null : null, maxLines: field.$1 == 'adresse' || field.$1 == 'tva' ? 2 : 1),
        const SizedBox(height: 12),
      ],
      FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer')),
    ])),
  );
}

class DeplacementSettingsScreen extends StatefulWidget {
  const DeplacementSettingsScreen({super.key});

  @override
  State<DeplacementSettingsScreen> createState() => _DeplacementSettingsScreenState();
}

class _DeplacementSettingsScreenState extends State<DeplacementSettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fields = const [
    ('palier1Km', 'Distance à partir de laquelle le 1er palier s’applique (km)'),
    ('palier1Prix', 'Frais du 1er palier (€)'),
    ('palier2Km', 'Distance à partir de laquelle le 2e palier s’applique (km)'),
    ('palier2Prix', 'Frais du 2e palier (€)'),
    ('palier3Km', 'Distance à partir de laquelle le 3e palier s’applique (km)'),
    ('palier3Prix', 'Frais du 3e palier (€)'),
    ('distanceMax', 'Distance au-delà de laquelle c’est "Sur devis" (km)'),
  ];
  final _controllers = <String, TextEditingController>{};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    for (final field in _fields) {
      _controllers[field.$1] = TextEditingController();
    }
    _load();
  }

  Future<void> _load() async {
    final values = await AppDatabase.instance.deplacementSettings();
    for (final entry in _controllers.entries) {
      entry.value.text = '${values[entry.key] ?? 0}';
    }
    if (mounted) setState(() => _loaded = true);
  }

  @override
  void dispose() {
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    await AppDatabase.instance.updateDeplacementSettings({
      for (final entry in _controllers.entries) entry.key: int.parse(entry.value.text.trim()),
    });
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Déplacements')),
    body: !_loaded
        ? const Center(child: CircularProgressIndicator())
        : Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'Ces paliers déterminent les frais de déplacement calculés automatiquement dans les interventions, à partir de la distance saisie.',
                ),
                const SizedBox(height: 16),
                for (final field in _fields) ...[
                  TextFormField(
                    controller: _controllers[field.$1],
                    decoration: InputDecoration(labelText: field.$2),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      final parsed = int.tryParse(value ?? '');
                      return parsed == null || parsed < 0 ? 'Nombre invalide' : null;
                    },
                  ),
                  const SizedBox(height: 12),
                ],
                const SizedBox(height: 8),
                FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer')),
              ],
            ),
          ),
  );
}
