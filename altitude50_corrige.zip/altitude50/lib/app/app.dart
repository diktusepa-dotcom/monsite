import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../features/clients/presentation/screens/clients_screen.dart';
import '../features/devis/presentation/screens/devis_screen.dart';
import '../features/factures/presentation/screens/factures_screen.dart';
import '../features/home/presentation/screens/home_screen.dart';
import '../features/more/presentation/screens/more_screen.dart';
import 'theme/app_theme.dart';

/// Observateur de navigation partagé : permet à un écran de tab (ex. Clients)
/// de savoir qu'il redevient visible après qu'une fenêtre poussée par-dessus
/// (fiche client, formulaire…) a été fermée, pour se rafraîchir à ce moment-là.
final routeObserver = RouteObserver<ModalRoute<void>>();

class Altitude50App extends StatelessWidget {
  const Altitude50App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Alt'itude 50",
      debugShowCheckedModeBanner: false,
      locale: const Locale('fr', 'FR'),
      supportedLocales: const [Locale('fr', 'FR')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      navigatorObservers: [routeObserver],
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _selectedIndex = 0;
  int _clientsRefreshKey = 0;

  void _openClientsAfterCreation() {
    setState(() {
      _selectedIndex = 1;
      _clientsRefreshKey++;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(onClientCreated: _openClientsAfterCreation),
      ClientsScreen(key: ValueKey(_clientsRefreshKey)),
      const DevisScreen(),
      const FacturesScreen(),
      const MoreScreen(),
    ];
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Clients'),
          NavigationDestination(icon: Icon(Icons.description_outlined), selectedIcon: Icon(Icons.description), label: 'Devis'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Factures'),
          NavigationDestination(icon: Icon(Icons.more_horiz_outlined), selectedIcon: Icon(Icons.more_horiz), label: 'Plus'),
        ],
      ),
    );
  }
}
