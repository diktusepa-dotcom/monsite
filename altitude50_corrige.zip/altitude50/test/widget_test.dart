// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:altitude50/app/app.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('App renders the home shell', (WidgetTester tester) async {
    await tester.pumpWidget(const Altitude50App());

    expect(find.text("Alt'itude 50"), findsWidgets);
    expect(find.text('Accueil'), findsOneWidget);
  });
}
