import 'dart:convert';

import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/data/models/devis_model.dart';
import 'package:altitude50/data/models/facture_model.dart';
import 'package:altitude50/data/models/intervention_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Local persistence', () {
    setUp(() async {
      await AppDatabase.instance.resetForTesting();
    });

    test('persists a client and intervention across a fresh database open', () async {
      final client = ClientModel(
        id: null,
        nom: 'Martin',
        prenom: 'Claire',
        telephone: '0601020304',
        email: 'claire@example.com',
        adresse: '12 rue des Lilas',
        codePostal: '69001',
        ville: 'Lyon',
        notes: 'Client VIP',
        dateCreation: DateTime.now().toIso8601String(),
      );

      final persistedClient = await AppDatabase.instance.insertClient(client);
      expect(persistedClient.id, isNotNull);

      final prestations = await AppDatabase.instance.prestations();
      final insertedPrestation = prestations.firstWhere((item) => item.nom == 'Installation / configuration imprimante');
      expect(insertedPrestation.prix, 69);

      final intervention = InterventionModel(
        id: null,
        clientId: persistedClient.id!,
        date: '2026-08-30',
        heure: '09:30',
        appareil: 'Chaudière',
        marque: 'Viessmann',
        modele: 'Vitodens 100-W',
        problemeSignale: 'Bruit inhabituel',
        diagnostic: 'Filtre à nettoyer',
        travailEffectue: 'Nettoyage et vérification',
        prestationId: insertedPrestation.id!,
        prixPrestation: insertedPrestation.prix,
        fraisDeplacement: 0,
        total: insertedPrestation.prix,
        statut: 'À venir',
        modePaiement: 'Carte',
        notes: 'À vérifier',
        dateCreation: DateTime.now().toIso8601String(),
      );

      final insertedIntervention = await AppDatabase.instance.insertIntervention(intervention);
      expect(insertedIntervention.id, isNotNull);
      expect(insertedIntervention.total, 69);

      final secondIntervention = intervention.copyWith(
        id: null,
        fraisDeplacement: 10,
        total: 79,
      );
      final insertedSecondIntervention = await AppDatabase.instance.insertIntervention(secondIntervention);
      expect(insertedSecondIntervention.total, 79);

      await AppDatabase.instance.close();

      final reloadedClient = await AppDatabase.instance.clientById(persistedClient.id!);
      expect(reloadedClient?.nom, 'Martin');

      final reloadedIntervention = await AppDatabase.instance.interventionById(insertedIntervention.id!);
      expect(reloadedIntervention?.clientId, persistedClient.id!);
      expect(reloadedIntervention?.statut, 'À venir');
      expect(reloadedIntervention?.total, 69);
      final history = await AppDatabase.instance.interventionsByClient(persistedClient.id!);
      expect(history, hasLength(2));
      expect(history.map((item) => item.total), containsAll(<int>[69, 79]));

      final devis = await AppDatabase.instance.insertDevis(DevisModel(
        id: null,
        clientId: persistedClient.id!,
        numero: '',
        date: '2026-08-30',
        dateValidite: '2026-09-29',
        lignes: jsonEncode([{'prestationId': insertedPrestation.id, 'description': 'Installation imprimante', 'quantite': 1, 'prixUnitaire': 69, 'total': 69}]),
        deplacement: 10,
        remise: 0,
        total: 79,
        statut: 'Brouillon',
        notes: '',
      ));
      expect(devis.numero, startsWith('DEV-2026-'));
      final acceptedDevis = devis.copyWith(statut: 'Accepté');
      await AppDatabase.instance.updateDevis(acceptedDevis);
      final facture = await AppDatabase.instance.insertFacture(FactureModel(
        id: null,
        clientId: persistedClient.id!,
        numero: '',
        date: '2026-08-30',
        interventionId: 0,
        devisId: devis.id!,
        lignes: devis.lignes,
        deplacement: 10,
        remise: 0,
        total: 79,
        statutPaiement: 'Brouillon',
        modePaiement: 'Carte',
      ));
      expect(facture.total, 79);
      expect(facture.numero, startsWith('FAC-2026-'));
      expect(await AppDatabase.instance.nextFactureNumber(), isNot(facture.numero));
      await AppDatabase.instance.close();
      final persistedFactures = await AppDatabase.instance.facturesByClient(persistedClient.id!);
      expect(persistedFactures.single.total, 79);
    });
  });
}
