import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  print('[IMPORT ONLY 01] FILE LOADED');

  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    print('[IMPORT ONLY 02] SETUP');
  });

  testWidgets('import only structure', (tester) async {
    print('[IMPORT ONLY 03] TEST START');

    await tester.pumpWidget(const SizedBox());

    print('[IMPORT ONLY 04] TEST AFTER PUMP');

    expect(find.byType(SizedBox), findsOneWidget);

    print('[IMPORT ONLY 05] SUCCESS');
  });
}
