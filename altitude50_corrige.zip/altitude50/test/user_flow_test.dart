import 'package:altitude50/app/app.dart';
import 'package:altitude50/data/database/app_database.dart';
import 'package:altitude50/data/models/client_model.dart';
import 'package:altitude50/features/clients/presentation/screens/client_form_screen.dart';
import 'package:altitude50/features/home/presentation/screens/home_screen.dart';
import 'package:altitude50/features/interventions/presentation/screens/intervention_form_screen.dart';
import 'package:altitude50/features/devis/presentation/screens/devis_form_screen.dart';
import 'package:altitude50/features/factures/presentation/screens/facture_form_screen.dart';
import 'package:altitude50/features/tarifs/presentation/widgets/prestation_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    await AppDatabase.instance.resetForTesting();
  });

  testWidgets('creates a client from the home shortcut and opens its detail', (tester) async {
    await tester.pumpWidget(const Altitude50App());
    await tester.pumpAndSettle();

    await tester.tap(find.descendant(of: find.byType(HomeScreen), matching: find.text('Nouveau client')));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 200));
    expect(find.byType(ClientFormScreen), findsOneWidget);

    final fields = find.byType(TextFormField);
    expect(fields, findsNWidgets(8));
    await tester.enterText(fields.at(0), 'Martin');
    await tester.enterText(fields.at(1), 'Claire');
    await tester.enterText(fields.at(2), '0601020304');
    await tester.enterText(fields.at(4), '12 rue des Lilas');
    await tester.enterText(fields.at(5), '69001');
    await tester.enterText(fields.at(6), 'Lyon');
    await tester.drag(find.byType(ListView).last, const Offset(0, -800));
    await tester.pump();
    final saveButton = find.widgetWithText(FilledButton, 'Enregistrer');
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    final clients = await AppDatabase.instance.clients();
    final createdClient = clients.singleWhere(
      (client) => client.nom == 'Martin' && client.prenom == 'Claire',
    );
    expect(createdClient.id, isNotNull);

    final claireFinder = find.byKey(ValueKey('client_${createdClient.id}'));
    expect(claireFinder, findsOneWidget);
    await tester.ensureVisible(claireFinder);
    await tester.tap(claireFinder);
    await tester.pumpAndSettle();
    expect(find.text('Nouvelle intervention'), findsOneWidget);
  });

  testWidgets('creates an intervention with a SQLite tariff and calculated travel', (tester) async {
    final client = await AppDatabase.instance.insertClient(_client());
    await tester.pumpWidget(MaterialApp(home: InterventionFormScreen(client: client)));
    await tester.pumpAndSettle();

    await tester.tap(find.byType(PrestationPickerField));
    await tester.pumpAndSettle();

    await tester.tap(find.text('ORDINATEUR'));
    await tester.pumpAndSettle();

    final interventionPrestationText =
        find.text('Assistance / dépannage').last;

    expect(interventionPrestationText, findsOneWidget);
    await tester.tap(interventionPrestationText);
    await tester.pumpAndSettle();

    final fields = find.byType(TextFormField);
    await tester.enterText(fields.at(0), 'Ordinateur');
    await tester.enterText(fields.at(6), '15');
    expect(find.text('79 €'), findsWidgets);
    await tester.drag(find.byType(ListView).last, const Offset(0, -800));
    await tester.pump();
    final saveButton = find.byType(FilledButton).last;
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pump(const Duration(seconds: 1));
    final interventions = await AppDatabase.instance.interventionsByClient(client.id!);
    expect(interventions.single.total, 79);
  });

  testWidgets('creates a quote and a linked invoice from the accepted quote', (tester) async {
    final client = await AppDatabase.instance.insertClient(_client());
    await tester.pumpWidget(MaterialApp(home: DevisFormScreen(client: client)));
    await tester.pump(const Duration(seconds: 1));

    await tester.pumpAndSettle();
    await tester.tap(find.byType(PrestationPickerField));
    await tester.pumpAndSettle();

    await tester.tap(find.text('ORDINATEUR'));
    await tester.pumpAndSettle();

    final devisPrestationText =
        find.text('Assistance / dépannage').last;

    expect(devisPrestationText, findsOneWidget);
    await tester.tap(devisPrestationText);
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(1), '10');
    await tester.drag(find.byType(ListView).last, const Offset(0, -800));
    await tester.pump();
    final saveButton = find.byType(FilledButton).last;
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pump(const Duration(seconds: 1));

    final devis = (await AppDatabase.instance.devisByClient(client.id!)).single;
    expect(devis.total, 79);
    expect(devis.numero, startsWith('DEV-'));
    await AppDatabase.instance.updateDevis(devis.copyWith(statut: 'Accepté'));

    await tester.pumpWidget(MaterialApp(home: FactureFormScreen(client: client, devis: devis)));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('Enregistrer').last);
    await tester.tap(find.text('Enregistrer').last);
    await tester.pump(const Duration(seconds: 1));

    final facture = (await AppDatabase.instance.facturesByClient(client.id!)).single;
    expect(facture.total, 79);
    expect(facture.devisId, devis.id);
    expect(facture.numero, startsWith('FAC-'));
  });
}

ClientModel _client() => ClientModel(
  id: null,
  nom: 'Test',
  prenom: 'Client',
  telephone: '0600000000',
  email: '',
  adresse: '1 rue Test',
  codePostal: '75000',
  ville: 'Paris',
  notes: '',
  dateCreation: DateTime.now().toIso8601String(),
);

